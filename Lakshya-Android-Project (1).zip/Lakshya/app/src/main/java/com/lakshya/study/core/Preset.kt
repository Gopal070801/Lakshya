package com.lakshya.study.core

/* Static content: syllabus preset, mistake reasons, themes, quotes, badges' text … */

data class StatInfo(val label: String, val ico: String)

val STAT: Map<String, StatInfo> = linkedMapOf(
    Status.TODO to StatInfo("Baaki", "○"),
    Status.LEARNING to StatInfo("Padh rahe", "◐"),
    Status.DONE to StatInfo("Complete", "●")
)

data class Reason(val key: String, val label: String, val short: String, val color: String, val ico: String, val fix: String)

val REASONS: List<Reason> = listOf(
    Reason("forgot", "Padha tha, yaad nahi aaya", "Yaad nahi", "#fbbf24", "🧠", "Notes/flashcards se roz dohrao (spaced revision)."),
    Reason("silly", "Silly mistake", "Silly", "#f87171", "🤦", "Question poora padho, NOT/EXCEPT check karo, mark karne se pehle option dobara dekho."),
    Reason("notstudied", "Topic padha hi nahi", "Padha nahi", "#a78bfa", "📕", "Ye topic syllabus me pehle cover karo, phir PYQ practice."),
    Reason("confused", "2 options me confuse", "Confuse", "#60a5fa", "🔀", "Concept clear karo aur milte-julte facts ka compare table banao."),
    Reason("guess", "Tukka galat laga", "Tukka", "#2dd4bf", "🎲", "Elimination use karo; sure na ho to skip karo (negative marking bachegi)."),
    Reason("time", "Time nahi mila", "Time", "#94a3b8", "⏱", "Sectional timed tests do. Easy questions pehle, GA/English jaldi nipta lo.")
)
val REASON_KEYS: List<String> = REASONS.map { it.key }
fun reasonOf(key: String): Reason = REASONS.firstOrNull { it.key == key } ?: REASONS[1]

val INTS = listOf(1, 3, 7, 14, 30, 60)      // topic revision gaps (days)
val BOX = listOf(1, 3, 7, 14, 30)           // mistake-card (Leitner) gaps
val TEST_TYPES = listOf("Full Mock", "Sectional", "Topic Test", "PYQ", "Quiz")
val EMOJIS = listOf("📘", "📗", "📕", "🌍", "🧮", "🧠", "🔬", "⚗️", "🧬", "🏛", "💰", "🗣", "✍️", "📐", "⚽", "🎨", "💻", "⚖️", "🧪", "📰")
val COLORS = listOf("#f5a524", "#2dd4bf", "#a78bfa", "#fb7185", "#60a5fa", "#34d399", "#f472b6", "#fbbf24", "#fb923c", "#22d3ee")
val HABIT_EMOJIS = listOf("📰", "📖", "📝", "🏃", "😴", "📵", "💧", "🧘", "🥗", "✍️", "🎧", "🔁")
val HABIT_SUG = listOf(
    "📰" to "Current Affairs padhna", "📖" to "10 naye words", "📝" to "PYQ practice",
    "🏃" to "Exercise / walk", "😴" to "Time par sona", "📵" to "Social media band (2h)"
)

val QUOTES = listOf(
    "Roz thoda sa, par roz: yahi jeet ki chaabi hai.",
    "Mock me galti karna fail hona nahi, sikhna hai.",
    "Aaj ki mehnat, kal ka selection.",
    "Discipline motivation se bada hota hai.",
    "Ek ek topic, ek ek din: syllabus khatam ho jayega.",
    "Jo aaj revise karta hai, wo exam me bhoolta nahi.",
    "Silly mistakes hi merit se door rakhti hain. Dhyan se padho.",
    "Chhote steps bhi manzil tak pahunchate hain.",
    "Phone side me, focus on. Sirf 25 minute.",
    "Kal ke khud se behtar bano, dusron se tulna mat karo.",
    "Consistency > Intensity.",
    "Sapne wo nahi jo neend me aaye, wo hain jo neend na aane de."
)

val TITLES = listOf("Beginner 🌱", "Learner 📘", "Achiever ⭐", "Warrior ⚔️", "Scholar 🎓", "Master 🏅", "Legend 👑")

data class ThemeDef(val id: String, val name: String, val light: Boolean, val bg: String, val acc: String, val acc2: String)

val THEMES: List<ThemeDef> = listOf(
    ThemeDef("system", "Auto", false, "#000000", "#3E91FF", "#6C7BFF"),
    ThemeDef("midnight", "Midnight", false, "#0b0e17", "#7c9cff", "#b18cff"),
    ThemeDef("amoled", "AMOLED", false, "#000000", "#8b9dff", "#e879f9"),
    ThemeDef("aurora", "Aurora", false, "#07131a", "#2dd4bf", "#8b5cf6"),
    ThemeDef("ocean", "Ocean", false, "#06101f", "#38bdf8", "#6366f1"),
    ThemeDef("forest", "Forest", false, "#0a140f", "#4ade80", "#a3e635"),
    ThemeDef("sunset", "Sunset", false, "#160d12", "#fb923c", "#f43f5e"),
    ThemeDef("cyber", "Cyber", false, "#09090f", "#a3e635", "#22d3ee"),
    ThemeDef("sakura", "Sakura", true, "#fdf2f6", "#ec4899", "#a855f7"),
    ThemeDef("paper", "Paper", true, "#f6f1e7", "#c2410c", "#dc2626"),
    ThemeDef("frost", "Frost", true, "#eef4fb", "#2563eb", "#7c3aed")
)
fun themeOf(id: String): ThemeDef = THEMES.firstOrNull { it.id == id } ?: THEMES[0]

val ACCENTS: List<Pair<String, String>> = listOf(
    "#7c9cff" to "#b18cff", "#2dd4bf" to "#22d3ee", "#34d399" to "#a3e635", "#fbbf24" to "#fb7185",
    "#fb923c" to "#f43f5e", "#f472b6" to "#a78bfa", "#e879f9" to "#6366f1", "#38bdf8" to "#2dd4bf"
)

/* ---------------- SSC MTS syllabus preset ---------------- */

class PresetSubject(
    val id: String, val name: String, val short: String, val emoji: String,
    val color: String, val merit: Boolean, val topics: List<String>
)

val P_MTS: List<PresetSubject> = listOf(
    PresetSubject("ga", "General Awareness", "GA", "🌍", "#f5a524", true, listOf(
        "History – Ancient", "History – Medieval", "History – Modern & Freedom Struggle*", "Geography – India*",
        "Geography – World", "Indian Polity & Constitution*", "Indian Economy", "Physics", "Chemistry",
        "Biology & Human Body*", "Books & Authors", "Awards & Honours", "Sports", "Important Days & Themes",
        "Capitals, Currencies & Organisations", "Current Affairs (last 6 months)*", "Science & Technology",
        "Art & Culture", "Govt. Schemes", "Environment & Ecology", "Miscellaneous GK")),
    PresetSubject("eng", "English", "English", "✍️", "#2dd4bf", true, listOf(
        "Synonyms*", "Antonyms*", "One Word Substitution*", "Idioms & Phrases*", "Spelling Error", "Error Spotting*",
        "Sentence Improvement", "Fill in the Blanks*", "Active / Passive Voice", "Direct / Indirect Speech",
        "Cloze Test", "Reading Comprehension", "Para Jumbles", "Tenses", "Prepositions", "Articles & Determiners",
        "Subject-Verb Agreement", "Vocabulary (Misc)")),
    PresetSubject("math", "Maths", "Maths", "🧮", "#a78bfa", false, listOf(
        "Number System", "Simplification & BODMAS", "Percentage", "Ratio & Proportion", "Average", "Profit & Loss",
        "Simple & Compound Interest", "Time & Work", "Time, Speed & Distance", "Algebra", "Geometry", "Mensuration",
        "Data Interpretation", "Fractions & Decimals")),
    PresetSubject("reas", "Reasoning", "Reasoning", "🧠", "#fb7185", false, listOf(
        "Number / Alphabet Series", "Analogy", "Classification (Odd one out)", "Coding-Decoding", "Blood Relations",
        "Direction Sense", "Venn Diagram", "Order & Ranking", "Non-Verbal / Figures", "Mathematical Operations",
        "Syllogism", "Calendar & Clock"))
)

fun mkTopic(sid: String, name: String, imp: Boolean = false): Topic =
    Topic(id = uid() + kotlin.random.Random.nextInt(1296).toString(36), sid = sid, name = name, imp = imp, created = System.currentTimeMillis())

class PresetData(val subjects: List<Subject>, val topics: List<Topic>)

fun buildPreset(): PresetData {
    val subs = ArrayList<Subject>()
    val tops = ArrayList<Topic>()
    for (p in P_MTS) {
        subs.add(Subject(p.id, p.name, p.short, p.emoji, p.color, p.merit, false))
        for (n in p.topics) {
            val imp = n.endsWith("*")
            tops.add(mkTopic(p.id, if (imp) n.dropLast(1) else n, imp))
        }
    }
    return PresetData(subs, tops)
}

fun hexInt(h: String): Int {
    val t = h.removePrefix("#")
    val v = t.toLongOrNull(16) ?: 0x7c9cffL
    return (0xFF000000L or (v and 0xFFFFFFL)).toInt()
}
