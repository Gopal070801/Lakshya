package com.lakshya.study.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.QUOTES
import com.lakshya.study.core.Status
import com.lakshya.study.core.dayDiff
import com.lakshya.study.core.fmtD
import com.lakshya.study.core.fmtDur
import com.lakshya.study.core.fmtHrs
import com.lakshya.study.core.hourOf
import com.lakshya.study.core.loadDemo
import com.lakshya.study.core.loadPreset
import com.lakshya.study.core.parseD
import com.lakshya.study.core.pct
import com.lakshya.study.core.to12
import com.lakshya.study.core.toggleTask
import com.lakshya.study.ui.Dest
import com.lakshya.study.ui.LocalSnap
import com.lakshya.study.ui.LocalStore
import com.lakshya.study.ui.LocalUi
import com.lakshya.study.ui.Sheet
import com.lakshya.study.ui.components.AppCard
import com.lakshya.study.ui.components.Badge
import com.lakshya.study.ui.components.Btn
import com.lakshya.study.ui.components.BtnKind
import com.lakshya.study.ui.components.CheckCircle
import com.lakshya.study.ui.components.EmptyCard
import com.lakshya.study.ui.components.Ic
import com.lakshya.study.ui.components.IconBtn
import com.lakshya.study.ui.components.ItemRow
import com.lakshya.study.ui.components.ProgressBar
import com.lakshya.study.ui.components.Ring
import com.lakshya.study.ui.components.Screen
import com.lakshya.study.ui.components.SectionTitle
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.components.colorOf
import com.lakshya.study.ui.theme.Th

@Composable
fun HomeScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val s = snap.s
    val c = Th.c
    val d = Th.d
    val nowMs = remember(snap) { System.currentTimeMillis() }
    val hour = hourOf(nowMs)
    val greet = when {
        hour < 5 -> "Raat ko bhi mehnat 🌙"
        hour < 12 -> "Good morning ☀️"
        hour < 17 -> "Good afternoon 🌤"
        hour < 21 -> "Good evening 🌆"
        else -> "Good night 🌙"
    }
    val name = s.profile.name.trim()

    Screen(
        title = if (name.isEmpty()) "Lakshya" else "Hi, $name",
        subtitle = greet,
        actions = { IconBtn(Ic.Gear, { ui.go(Dest.Settings) }, bg = c.surface) }
    ) {
        if (s.subjects.isEmpty()) {
            item {
                EmptyCard("🎯", "Chalo shuru karte hain", "Syllabus load karo ya demo data se app explore karo.") {
                    Btn("SSC MTS syllabus load karo", { store.commit { it.loadPreset() } }, big = true)
                    Spacer(Modifier.height(8.dp))
                    Btn("Demo data dekho", { store.commit { st -> loadDemo(st, System.currentTimeMillis()) } }, kind = BtnKind.Soft)
                }
            }
        }

        // ------------------------------------------------------------ hero
        item {
            val goal = s.profile.dailyGoal.coerceAtLeast(1)
            val mins = snap.dayMins(snap.today)
            val frac = (mins.toFloat() / goal).coerceIn(0f, 1f)
            val dl = if (s.profile.examDate.isNotEmpty()) dayDiff(snap.today, s.profile.examDate) else -1
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(d.card)).background(c.grad).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Tx("AAJ KA GOAL", size = 11.5.sp, weight = FontWeight.SemiBold, color = c.onAcc.copy(alpha = 0.75f))
                        Tx(fmtDur(mins * 60), Modifier.padding(top = 4.dp), size = 30.sp, weight = FontWeight.Bold, color = c.onAcc, maxLines = 1)
                        Tx("of ${fmtDur(goal * 60)}", size = 13.5.sp, color = c.onAcc.copy(alpha = 0.8f), maxLines = 1)
                        Spacer(Modifier.height(10.dp))
                        val chip = when {
                            dl > 0 -> "📅 ${s.profile.exam}: $dl din baaki"
                            dl == 0 -> "🔥 Aaj exam hai! All the best"
                            else -> "🎯 ${s.profile.exam}"
                        }
                        Box(Modifier.clip(RoundedCornerShape(50)).background(c.onAcc.copy(alpha = 0.18f)).padding(horizontal = 10.dp, vertical = 5.dp)) {
                            Tx(chip, size = 12.sp, weight = FontWeight.Medium, color = c.onAcc, maxLines = 1)
                        }
                    }
                    Ring(frac, size = 96.dp, stroke = 10.dp, color = c.onAcc, track = c.onAcc.copy(alpha = 0.25f)) {
                        Tx("${(frac * 100).toInt()}%", size = 18.sp, weight = FontWeight.Bold, color = c.onAcc, maxLines = 1)
                    }
                }
            }
        }

        // ------------------------------------------------------------ level + stats
        item {
            val lv = snap.level
            AppCard(onClick = { ui.go(Dest.Badges) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Tx("Level ${lv.level} · ${lv.title}", size = 15.sp, weight = FontWeight.Bold, maxLines = 1)
                        Tx("${lv.xp} XP", Modifier.padding(top = 2.dp), size = 12.sp, color = c.sub)
                    }
                    Tx("${lv.hi - lv.xp} XP to go", size = 12.sp, color = c.sub, maxLines = 1)
                }
                Spacer(Modifier.height(10.dp))
                ProgressBar(lv.p.toFloat().coerceIn(0f, 1f), c.acc, brush = c.grad)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile("🔥 ${snap.streak.cur}", "Streak", Modifier.weight(1f))
                    StatTile(fmtHrs(snap.totalSecs), "Total", Modifier.weight(1f))
                    val done = s.topics.count { it.status == Status.DONE }
                    StatTile("$done/${s.topics.size}", "Topics", Modifier.weight(1f))
                }
            }
        }

        // ------------------------------------------------------------ timetable now
        val bn = snap.blockNow(nowMs)
        if (bn.cur != null || bn.next != null) item {
            AppCard(onClick = { ui.go(Dest.Timetable) }) {
                val b = bn.cur ?: bn.next!!
                val sb = snap.sub(b.sid)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    com.lakshya.study.ui.components.EmojiBubble(sb.emoji, colorOf(sb.color))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Tx(if (bn.cur != null) "ABHI CHAL RAHA HAI" else "AGLA SLOT", size = 11.sp, weight = FontWeight.SemiBold, color = c.sub)
                        Tx(b.label.ifEmpty { sb.name }, size = 16.sp, weight = FontWeight.Bold, maxLines = 1)
                        Tx("${to12(b.start)} – ${to12(b.end)}", size = 12.5.sp, color = c.sub)
                    }
                    Btn("Focus", { ui.focusOn(b.sid, "") }, kind = BtnKind.Soft)
                }
            }
        }

        // ------------------------------------------------------------ due revisions
        val dueN = snap.dueTopics.size
        val cardN = snap.dueCards.size
        if (dueN + cardN > 0) item {
            AppCard(onClick = { ui.open(Sheet.RevHub) }, container = c.accSoft) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tx("🔁", size = 28.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Tx("Revision ka time", size = 16.sp, weight = FontWeight.Bold, color = c.accText)
                        Tx(
                            listOfNotNull(if (dueN > 0) "$dueN topics" else null, if (cardN > 0) "$cardN mistake cards" else null).joinToString(" + ") + " due",
                            size = 13.sp, color = c.accText
                        )
                    }
                    Badge("${dueN + cardN}", c.accText)
                }
            }
        }

        // ------------------------------------------------------------ today's tasks
        val tasks = snap.tasksOn(snap.today)
        item {
            SectionTitle("Aaj ke tasks", if (tasks.isNotEmpty()) "Sab dekho" else "Add", { if (tasks.isNotEmpty()) ui.tab(Dest.Plan) else ui.open(Sheet.TaskForm(null, snap.today)) })
        }
        if (tasks.isEmpty()) item {
            AppCard { Tx("Aaj ke liye koi task nahi. Plan tab me Smart Plan try karo ✨", size = 13.5.sp, color = c.sub) }
        } else item {
            AppCard {
                tasks.take(5).forEach { t ->
                    val sb = snap.subOrNull(t.sid)
                    ItemRow(
                        t.title, sub = listOfNotNull(sb?.short?.ifEmpty { sb.name }, "${t.est}m", if (t.time.isNotEmpty()) to12(t.time) else null).joinToString(" · "),
                        done = t.done, onClick = { ui.tab(Dest.Plan) },
                        leading = { CheckCircle(t.done) { ui.tick(); store.commit { st -> st.toggleTask(t.id, System.currentTimeMillis(), snap.today) } } }
                    )
                }
                if (tasks.size > 5) Tx("+${tasks.size - 5} aur", Modifier.padding(top = 4.dp), size = 12.5.sp, color = c.sub)
            }
        }

        // ------------------------------------------------------------ focus areas
        val fa = snap.focusAreas(3)
        if (fa.isNotEmpty()) {
            item { SectionTitle("Aaj kis par dhyan do") }
            item {
                AppCard {
                    fa.forEachIndexed { i, f ->
                        val sb = snap.sub(f.topic.sid)
                        ItemRow(
                            f.topic.name, sub = f.why.joinToString(" · "), emoji = sb.emoji, color = colorOf(sb.color),
                            onClick = { ui.focusOn(f.topic.sid, f.topic.id) },
                            trailing = { com.lakshya.study.ui.components.Icon(Ic.Next, c.sub, 18.dp) }
                        )
                        if (i < fa.size - 1) com.lakshya.study.ui.components.Divider()
                    }
                }
            }
        }

        // ------------------------------------------------------------ forecast
        if (s.topics.isNotEmpty()) item {
            val f = snap.syllabusForecast()
            AppCard {
                Tx("🗺 Syllabus forecast", size = 13.sp, weight = FontWeight.SemiBold, color = c.sub)
                Tx(f.text, Modifier.padding(top = 4.dp), size = 14.sp, color = if (f.late) c.warn else c.text, lineHeight = 20.sp)
            }
        }

        // ------------------------------------------------------------ shortcuts
        item { SectionTitle("Shortcuts") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickTile(Ic.Chart, "Analysis", Modifier.weight(1f)) { ui.go(Dest.Analysis) }
                    QuickTile(Ic.Note, "Notebook", Modifier.weight(1f)) { ui.go(Dest.Notebook) }
                    QuickTile(Ic.Table, "Timetable", Modifier.weight(1f)) { ui.go(Dest.Timetable) }
                    QuickTile(Ic.Habit, "Habits", Modifier.weight(1f)) { ui.go(Dest.Habits) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickTile(Ic.Grid, "Stats", Modifier.weight(1f)) { ui.go(Dest.Stats) }
                    QuickTile(Ic.Trophy, "Badges", Modifier.weight(1f)) { ui.go(Dest.Badges) }
                    QuickTile(Ic.Palette, "Look", Modifier.weight(1f)) { ui.go(Dest.Look) }
                    QuickTile(Ic.Gear, "Settings", Modifier.weight(1f)) { ui.go(Dest.Settings) }
                }
            }
        }

        // ------------------------------------------------------------ quote
        item {
            val q = QUOTES[parseD(snap.today).dayOfYear % QUOTES.size]
            Tx("“$q”", Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), size = 13.sp, color = c.sub, align = androidx.compose.ui.text.style.TextAlign.Center, lineHeight = 19.sp)
        }
    }
}
