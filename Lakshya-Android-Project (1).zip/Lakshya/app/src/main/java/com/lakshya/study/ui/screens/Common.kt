package com.lakshya.study.ui.screens

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.Codec
import com.lakshya.study.ui.LocalSnap
import com.lakshya.study.ui.LocalStore
import com.lakshya.study.ui.LocalUi
import com.lakshya.study.ui.components.Ic
import com.lakshya.study.ui.components.Icon
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.components.colorOf
import com.lakshya.study.ui.components.pressable
import com.lakshya.study.ui.theme.Th

@Composable
fun StatTile(value: String, label: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified) {
    val c = Th.c
    Column(
        modifier.clip(RoundedCornerShape(Th.d.inner)).background(c.surface2).padding(horizontal = 8.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Tx(value, size = 18.sp, weight = FontWeight.Bold, color = if (color == Color.Unspecified) c.text else color, maxLines = 1)
        Tx(label, Modifier.padding(top = 2.dp), size = 11.5.sp, color = c.sub, maxLines = 1)
    }
}

@Composable
fun QuickTile(ic: Ic, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = Th.c
    Column(
        modifier.clip(RoundedCornerShape(Th.d.inner)).background(c.surface).pressable(scaleTo = 0.94f, onClick = onClick).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(ic, c.accText, 24.dp)
        Tx(label, Modifier.padding(top = 6.dp), size = 11.5.sp, weight = FontWeight.Medium, color = c.sub, maxLines = 1)
    }
}

/** Equal-width row helper. */
@Composable
fun Cols(gap: Int = 8, content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap.dp), content = content)
}

fun subColor(hex: String): Color = colorOf(hex)

/** Opens the system file picker and restores a Lakshya / MTS-tracker JSON backup. */
@Composable
fun rememberRestoreLauncher(onResult: (Boolean) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val store = LocalStore.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val ok = try {
                val txt = readText(ctx, uri)
                val st = Codec.decode(txt)
                store.commit { st.copy(timer = null) }
                true
            } catch (e: Throwable) { false }
            onResult(ok)
        }
    }
    return { launcher.launch(arrayOf("application/json", "text/plain", "application/octet-stream", "*/*")) }
}

private fun readText(ctx: Context, uri: Uri): String =
    ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: error("empty")
