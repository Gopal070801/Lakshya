package com.lakshya.study.ui.sheets

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.COLORS
import com.lakshya.study.core.DOW
import com.lakshya.study.core.EMOJIS
import com.lakshya.study.core.HABIT_EMOJIS
import com.lakshya.study.core.STAT
import com.lakshya.study.core.Status
import com.lakshya.study.core.addManualSession
import com.lakshya.study.core.addTopics
import com.lakshya.study.core.deleteBlock
import com.lakshya.study.core.deleteHabit
import com.lakshya.study.core.deleteSubject
import com.lakshya.study.core.deleteTask
import com.lakshya.study.core.deleteTopic
import com.lakshya.study.core.fmtD
import com.lakshya.study.core.reviseTopic
import com.lakshya.study.core.saveBlock
import com.lakshya.study.core.saveHabit
import com.lakshya.study.core.saveSubject
import com.lakshya.study.core.saveTask
import com.lakshya.study.core.saveTopic
import com.lakshya.study.core.to12
import com.lakshya.study.core.toggleArchive
import com.lakshya.study.ui.Dest
import com.lakshya.study.ui.LocalSnap
import com.lakshya.study.ui.LocalStore
import com.lakshya.study.ui.LocalUi
import com.lakshya.study.ui.Sheet
import com.lakshya.study.ui.components.Btn
import com.lakshya.study.ui.components.BtnKind
import com.lakshya.study.ui.components.Chip
import com.lakshya.study.ui.components.ChipFlow
import com.lakshya.study.ui.components.ChipScroll
import com.lakshya.study.ui.components.DateField
import com.lakshya.study.ui.components.Divider
import com.lakshya.study.ui.components.Field
import com.lakshya.study.ui.components.Hint
import com.lakshya.study.ui.components.Ic
import com.lakshya.study.ui.components.ItemRow
import com.lakshya.study.ui.components.Label
import com.lakshya.study.ui.components.OneSwitch
import com.lakshya.study.ui.components.SettingRow
import com.lakshya.study.ui.components.SheetFrame
import com.lakshya.study.ui.components.Segmented
import com.lakshya.study.ui.components.Stepper
import com.lakshya.study.ui.components.Swatch
import com.lakshya.study.ui.components.TimeField
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.components.colorOf
import com.lakshya.study.ui.theme.Th

@Composable
fun SheetContent(s: Sheet) {
    when (s) {
        is Sheet.TaskForm -> TaskSheet(s.id, s.date)
        is Sheet.SubjectForm -> SubjectSheet(s.id)
        is Sheet.TopicEdit -> TopicEditSheet(s.id)
        is Sheet.TopicAdd -> TopicAddSheet(s.sid)
        is Sheet.TestForm -> TestSheet(s.id)
        is Sheet.MistakeForm -> MistakeSheet(s.id, s.testId)
        is Sheet.BlockForm -> BlockSheet(s.id, s.day)
        is Sheet.HabitForm -> HabitSheet(s.id)
        Sheet.Manual -> ManualSheet()
        Sheet.Menu -> MenuSheet()
        Sheet.RevHub -> RevHubSheet()
    }
}

// ------------------------------------------------------------------ shared pickers
@Composable
internal fun SubChips(sid: String, onSel: (String) -> Unit, only: Collection<String>? = null, allowNone: Boolean = false) {
    val snap = LocalSnap.current
    ChipScroll {
        if (allowNone) Chip("Koi nahi", sid.isEmpty(), { onSel("") })
        snap.activeSubs.filter { only == null || only.contains(it.id) }.forEach { sb ->
            Chip(sb.emoji + " " + snap.shortOf(sb), sb.id == sid, { onSel(sb.id) }, color = colorOf(sb.color))
        }
    }
}

@Composable
internal fun TopicChips(sid: String, tid: String, onSel: (String) -> Unit) {
    val snap = LocalSnap.current
    val tops = snap.topicsOf(sid)
    if (sid.isEmpty() || tops.isEmpty()) return
    ChipScroll {
        Chip("Koi nahi", tid.isEmpty(), { onSel("") })
        tops.take(80).forEach { t -> Chip(t.name, tid == t.id, { onSel(t.id) }) }
    }
}

// ------------------------------------------------------------------ task
@Composable
private fun TaskSheet(id: String?, date0: String?) {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val old = remember { snap.s.tasks.firstOrNull { it.id == id } }
    var title by remember { mutableStateOf(old?.title ?: "") }
    var date by remember { mutableStateOf(old?.date ?: date0 ?: ui.planDate.ifEmpty { snap.today }) }
    var sid by remember { mutableStateOf(old?.sid ?: "") }
    var tid by remember { mutableStateOf(old?.tid ?: "") }
    var est by remember { mutableStateOf(old?.est ?: 30) }
    var time by remember { mutableStateOf(old?.time ?: "") }

    SheetFrame(
        if (old == null) "Naya task" else "Task edit", { ui.closeSheet() },
        footer = {
            if (old != null) Btn("Delete", { store.commit { it.deleteTask(old.id) }; ui.closeSheet() }, kind = BtnKind.Danger)
            Btn("Save", {
                val name = title.trim().ifEmpty { snap.topic(tid)?.name ?: "" }
                if (name.isEmpty()) { ui.toast("Task ka naam likho", "bad"); return@Btn }
                store.commit { it.saveTask(old?.id, date, name, sid, tid, est, time, System.currentTimeMillis()) }
                ui.closeSheet()
            }, Modifier.weight(1f))
        }
    ) {
        Label("Kya karna hai?", Modifier.padding(top = 4.dp))
        Field(title, { title = it }, hint = "Jaise: Polity – Fundamental Rights", maxLen = 80)
        Label("Date"); DateField(date, { if (it.isNotEmpty()) date = it })
        Label("Subject"); SubChips(sid, { sid = it; tid = "" }, allowNone = true)
        if (sid.isNotEmpty()) { Label("Topic"); TopicChips(sid, tid) { tid = it } }
        SettingRow("Estimated time", "$est min") { Stepper({ est = (est - 5).coerceAtLeast(5) }, { est = (est + 5).coerceAtMost(300) }) }
        Label("Time (optional)"); TimeField(time, { time = it }, allowClear = true, placeholder = "Koi fixed time nahi")
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ subject
@Composable
private fun SubjectSheet(id: String?) {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val old = remember { snap.s.subjects.firstOrNull { it.id == id } }
    var name by remember { mutableStateOf(old?.name ?: "") }
    var short by remember { mutableStateOf(old?.short ?: "") }
    var emoji by remember { mutableStateOf(old?.emoji ?: EMOJIS[0]) }
    var color by remember { mutableStateOf(old?.color ?: COLORS[0]) }
    var merit by remember { mutableStateOf(old?.merit ?: false) }

    SheetFrame(
        if (old == null) "Naya subject" else "Subject edit", { ui.closeSheet() },
        footer = {
            Btn("Save", {
                if (name.isBlank()) { ui.toast("Subject ka naam likho", "bad"); return@Btn }
                store.commit { it.saveSubject(old?.id, name.trim(), short.trim(), emoji, color, merit) }
                ui.closeSheet()
            }, Modifier.weight(1f))
        }
    ) {
        Label("Naam", Modifier.padding(top = 4.dp)); Field(name, { name = it }, hint = "General Awareness", maxLen = 40)
        Label("Short naam"); Field(short, { short = it }, hint = "GA", maxLen = 12)
        Label("Emoji")
        ChipFlow { EMOJIS.forEach { e -> Chip(e, e == emoji, { emoji = e }) } }
        Label("Color")
        ChipFlow { COLORS.forEach { c -> Swatch(colorOf(c), c == color) { color = c } } }
        SettingRow("Merit subject ⭐", "Merit score isi subject ke marks se banta hai") { OneSwitch(merit) { merit = it } }
        if (old != null) {
            Divider()
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn(if (old.archived) "Unarchive" else "Archive", { store.commit { it.toggleArchive(old.id) }; ui.closeSheet() }, Modifier.weight(1f), kind = BtnKind.Ghost)
                Btn("Delete", {
                    ui.confirm("Subject delete?", "${snap.topicsOf(old.id).size} topics aur uske tasks/notes bhi hat jayenge.", "Delete") {
                        store.commit { it.deleteSubject(old.id) }
                        ui.closeSheet()
                        if (ui.top is Dest.Subject) ui.tab(Dest.Syllabus)
                    }
                }, Modifier.weight(1f), kind = BtnKind.Danger)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

// ------------------------------------------------------------------ topics
@Composable
private fun TopicEditSheet(id: String) {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val old = remember { snap.topic(id) }
    if (old == null) { SheetFrame("Topic", { ui.closeSheet() }) { Tx("Topic nahi mila.") }; return }
    var name by remember { mutableStateOf(old.name) }
    var status by remember { mutableStateOf(old.status) }
    var conf by remember { mutableStateOf(old.conf) }
    var imp by remember { mutableStateOf(old.imp) }
    var notes by remember { mutableStateOf(old.notes) }

    SheetFrame(
        "Topic edit", { ui.closeSheet() },
        footer = {
            Btn("Delete", {
                ui.confirm("Topic delete?", "\"${old.name}\" hata diya jayega.", "Delete") { store.commit { it.deleteTopic(id) }; ui.closeSheet() }
            }, kind = BtnKind.Danger)
            Btn("Save", {
                if (name.isBlank()) { ui.toast("Naam likho", "bad"); return@Btn }
                store.commit { it.saveTopic(id, name.trim(), status, conf, imp, notes.trim(), snap.today) }
                ui.closeSheet()
            }, Modifier.weight(1f))
        }
    ) {
        Label("Naam", Modifier.padding(top = 4.dp)); Field(name, { name = it }, maxLen = 80)
        Label("Status")
        Segmented(STAT.map { (k, v) -> k to v.label }, status, { status = it })
        Label("Confidence")
        ChipScroll {
            for (i in 0..5) Chip(if (i == 0) "–" else "★".repeat(i), conf == i, { conf = i })
        }
        SettingRow("Important ⭐", "Exam me baar baar aata hai") { OneSwitch(imp) { imp = it } }
        Label("Notes"); Field(notes, { notes = it }, hint = "Short notes, formulas, tricks…", singleLine = false, minLines = 3, maxLen = 1000)
        if (old.status == Status.DONE && old.due.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Hint("Agli revision: ${fmtD(old.due)} · ${old.rev} baar revise hua")
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun TopicAddSheet(sid: String) {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    var text by remember { mutableStateOf("") }
    SheetFrame(
        "Topics add karo", { ui.closeSheet() },
        footer = {
            Btn("Add", {
                store.commit { st -> st.addTopics(sid, text).first }
                val n = text.split("\n").count { it.isNotBlank() }
                ui.toast(if (n > 0) "Topics add hue ✅" else "Kuch likha nahi", if (n > 0) "ok" else "bad")
                if (n > 0) ui.closeSheet()
            }, Modifier.weight(1f))
        }
    ) {
        Hint("Ek line = ek topic. Important topic ke end me * lagao.")
        Spacer(Modifier.height(10.dp))
        Field(text, { text = it }, hint = "Fundamental Rights*\nDPSP\nPreamble", singleLine = false, minLines = 6, maxLen = 4000)
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ manual time
@Composable
private fun ManualSheet() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    var date by remember { mutableStateOf(snap.today) }
    var mins by remember { mutableStateOf(30) }
    var sid by remember { mutableStateOf(ui.focusSid.ifEmpty { snap.s.lastSid.ifEmpty { snap.activeSubs.firstOrNull()?.id ?: "" } }) }
    var tid by remember { mutableStateOf("") }
    SheetFrame(
        "Manual time", { ui.closeSheet() },
        footer = {
            Btn("Add", {
                store.commit { it.addManualSession(date, mins, sid, tid) }
                ui.toast("$mins min add hue ✅", "ok"); ui.closeSheet()
            }, Modifier.weight(1f))
        }
    ) {
        Label("Date", Modifier.padding(top = 4.dp)); DateField(date, { if (it.isNotEmpty()) date = it }, max = snap.today)
        SettingRow("Kitna time", "${mins / 60}h ${mins % 60}m") { Stepper({ mins = (mins - 5).coerceAtLeast(5) }, { mins = (mins + 5).coerceAtMost(720) }) }
        Label("Subject"); SubChips(sid, { sid = it; tid = "" })
        if (sid.isNotEmpty()) { Label("Topic (optional)"); TopicChips(sid, tid) { tid = it } }
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ habit
@Composable
private fun HabitSheet(id: String?) {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val old = remember { snap.s.habits.firstOrNull { it.id == id } }
    var name by remember { mutableStateOf(old?.name ?: "") }
    var emoji by remember { mutableStateOf(old?.emoji ?: HABIT_EMOJIS[0]) }
    SheetFrame(
        if (old == null) "Nayi habit" else "Habit edit", { ui.closeSheet() },
        footer = {
            if (old != null) Btn("Delete", { ui.confirm("Habit delete?", "Poori history hat jayegi.", "Delete") { store.commit { it.deleteHabit(old.id) }; ui.closeSheet() } }, kind = BtnKind.Danger)
            Btn("Save", {
                if (name.isBlank()) { ui.toast("Habit ka naam likho", "bad"); return@Btn }
                store.commit { it.saveHabit(old?.id, emoji, name.trim(), System.currentTimeMillis()) }
                ui.closeSheet()
            }, Modifier.weight(1f))
        }
    ) {
        Label("Naam", Modifier.padding(top = 4.dp)); Field(name, { name = it }, hint = "Roz Current Affairs", maxLen = 40)
        Label("Emoji"); ChipFlow { HABIT_EMOJIS.forEach { e -> Chip(e, e == emoji, { emoji = e }) } }
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ timetable block
@Composable
private fun BlockSheet(id: String?, day: Int) {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val old = remember { snap.s.blocks.firstOrNull { it.id == id } }
    var days by remember { mutableStateOf(old?.days?.toSet() ?: setOf(day)) }
    var sid by remember { mutableStateOf(old?.sid ?: snap.activeSubs.firstOrNull()?.id ?: "") }
    var label by remember { mutableStateOf(old?.label ?: "") }
    var start by remember { mutableStateOf(old?.start ?: "") }
    var end by remember { mutableStateOf(old?.end ?: "") }
    SheetFrame(
        if (old == null) "Naya slot" else "Slot edit", { ui.closeSheet() },
        footer = {
            if (old != null) Btn("Delete", { store.commit { it.deleteBlock(old.id) }; ui.closeSheet() }, kind = BtnKind.Danger)
            Btn("Save", {
                if (days.isEmpty()) { ui.toast("Kam se kam ek din chuno", "bad"); return@Btn }
                val nameOf = { x: String -> snap.sub(x).name }
                val r = snap.s.saveBlock(old?.id, days.sorted(), sid, start, end, label.trim(), nameOf)
                if (r.second != null) ui.toast(r.second!!, "bad")
                else { store.commit { it.saveBlock(old?.id, days.sorted(), sid, start, end, label.trim(), nameOf).first }; ui.closeSheet() }
            }, Modifier.weight(1f))
        }
    ) {
        Label("Din", Modifier.padding(top = 4.dp))
        ChipScroll { DOW.forEachIndexed { i, d -> Chip(d, days.contains(i), { days = if (days.contains(i)) days - i else days + i }) } }
        Label("Subject"); SubChips(sid, { sid = it })
        Label("Label (optional)"); Field(label, { label = it }, hint = "Jaise: Morning GA", maxLen = 30)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) { Label("Start"); TimeField(start, { start = it }) }
            Column(Modifier.weight(1f)) { Label("End"); TimeField(end, { end = it }) }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ revision hub
@Composable
private fun RevHubSheet() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val c = Th.c
    val topics = snap.dueTopics.sortedBy { it.due }.take(12)
    val cards = snap.dueCards
    SheetFrame("Revision hub", { ui.closeSheet() }) {
        if (cards.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Btn("🃏 ${cards.size} mistake cards revise karo", { ui.closeSheet(); ui.startRevise(cards.sortedBy { it.due }.take(30).map { it.id }) }, Modifier.fillMaxWidth(), big = true)
        }
        Label("Topics ka revision (${snap.dueTopics.size})")
        if (topics.isEmpty()) Tx("Koi topic due nahi 🎉", size = 14.sp, color = c.sub)
        topics.forEachIndexed { i, t ->
            val sb = snap.sub(t.sid)
            ItemRow(
                t.name, sub = sb.name + " · due " + fmtD(t.due), emoji = sb.emoji, color = colorOf(sb.color),
                trailing = { Btn("Revised", { ui.tick(); store.commit { it.reviseTopic(t.id, snap.today) } }, kind = BtnKind.Soft) }
            )
            if (i < topics.size - 1) Divider()
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ quick add
@Composable
private fun MenuSheet() {
    val ui = LocalUi.current
    SheetFrame("Quick add", { ui.closeSheet() }) {
        listOf(
            Triple("☑️", "Task", { ui.open(Sheet.TaskForm(null, null)) }),
            Triple("📝", "Mock test", { ui.open(Sheet.TestForm(null)) }),
            Triple("📓", "Mistake note", { ui.open(Sheet.MistakeForm(null, null)) }),
            Triple("⏱", "Manual time", { ui.open(Sheet.Manual) }),
            Triple("🌱", "Habit", { ui.open(Sheet.HabitForm(null)) })
        ).forEach { (e, t, f) -> ItemRow(t, emoji = e, onClick = f) }
        Spacer(Modifier.height(8.dp))
    }
}
