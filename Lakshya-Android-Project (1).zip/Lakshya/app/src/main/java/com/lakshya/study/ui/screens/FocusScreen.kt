package com.lakshya.study.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.Status
import com.lakshya.study.core.clock
import com.lakshya.study.core.deleteSession
import com.lakshya.study.core.fmtDur
import com.lakshya.study.core.nowHM
import com.lakshya.study.core.tElapsed
import com.lakshya.study.core.to12
import com.lakshya.study.ui.LocalSnap
import com.lakshya.study.ui.LocalStore
import com.lakshya.study.ui.LocalUi
import com.lakshya.study.ui.Sheet
import com.lakshya.study.ui.components.AppCard
import com.lakshya.study.ui.components.Btn
import com.lakshya.study.ui.components.BtnKind
import com.lakshya.study.ui.components.Chip
import com.lakshya.study.ui.components.ChipScroll
import com.lakshya.study.ui.components.Divider
import com.lakshya.study.ui.components.Ic
import com.lakshya.study.ui.components.IconBtn
import com.lakshya.study.ui.components.ItemRow
import com.lakshya.study.ui.components.Label
import com.lakshya.study.ui.components.Ring
import com.lakshya.study.ui.components.Screen
import com.lakshya.study.ui.components.SectionTitle
import com.lakshya.study.ui.components.Segmented
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.components.colorOf
import com.lakshya.study.ui.theme.Th

@Composable
fun FocusScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val c = Th.c
    val s = snap.s
    val t = s.timer

    Screen("Focus", subtitle = if (t == null) "Pomodoro ya free timer" else "Dhyan lagao 🎧") {
        if (t != null) {
            item {
                val now by store.now.collectAsState()
                val e = tElapsed(t, now)
                val brk = t.phase != "focus"
                val txt = if (t.planned > 0) clock(t.planned - e, true) else clock(e, false)
                val frac = if (t.planned > 0) (e / t.planned).toFloat().coerceIn(0f, 1f) else ((e % 3600) / 3600.0).toFloat()
                val sb = snap.subOrNull(t.sid)
                val col = if (brk) c.ok else if (sb != null) colorOf(sb.color) else c.acc
                AppCard {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Tx(
                            if (brk) (if (t.phase == "long") "☕ Lamba break" else "☕ Chhota break") else if (t.mode == "free") "⏱ Free timer" else "🍅 Focus session",
                            size = 14.sp, weight = FontWeight.SemiBold, color = c.sub
                        )
                        Spacer(Modifier.height(16.dp))
                        Ring(frac, size = 250.dp, stroke = 14.dp, color = col) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Tx(txt, size = 52.sp, weight = FontWeight.Bold, maxLines = 1)
                                Tx(if (t.running) "chal raha hai" else "paused", size = 13.sp, color = c.sub)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        if (!brk) {
                            val tp = snap.topic(t.tid)
                            Tx((sb?.emoji ?: "📚") + " " + (sb?.name ?: "General") + if (tp != null) " · ${tp.name}" else "", size = 14.sp, color = c.text, align = TextAlign.Center, maxLines = 2)
                            if (t.dist > 0) Tx("Distractions: ${t.dist}", Modifier.padding(top = 4.dp), size = 12.sp, color = c.warn)
                        }
                        Spacer(Modifier.height(20.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconBtn(Ic.Close, { ui.confirm("Timer discard?", "Ye session save nahi hoga.", "Discard") { store.timerDiscard() } }, bg = c.surface2, size = 52.dp)
                            Btn(if (t.running) "Pause" else "Resume", { ui.tick(); store.timerToggle() }, icon = if (t.running) Ic.Pause else Ic.Play, big = true)
                            IconBtn(Ic.Check, { ui.strongHaptic(); store.timerFinish() }, tint = c.onAcc, bg = c.ok, size = 52.dp)
                        }
                        if (!brk) {
                            Spacer(Modifier.height(12.dp))
                            Btn("📵 Distract hua (+1)", { ui.tick(); store.timerDistraction() }, kind = BtnKind.Ghost)
                        }
                    }
                }
            }
        } else {
            val sid = ui.focusSid.ifEmpty { s.lastSid.ifEmpty { snap.activeSubs.firstOrNull()?.id ?: "" } }
            item {
                AppCard {
                    Segmented(listOf("pomo" to "🍅 Pomodoro", "free" to "⏱ Free"), if (ui.focusFree) "free" else "pomo", { ui.focusFree = it == "free" })
                    Tx(
                        if (ui.focusFree) "Stopwatch jaisa. Jab chaho tab finish karo." else "${s.settings.pomo.focus}m focus · ${s.settings.pomo.short}m break · har ${s.settings.pomo.every} baad ${s.settings.pomo.long}m",
                        Modifier.padding(top = 10.dp), size = 12.5.sp, color = c.sub
                    )
                    if (snap.activeSubs.isNotEmpty()) {
                        Label("Subject")
                        ChipScroll {
                            snap.activeSubs.forEach { sb ->
                                Chip(sb.emoji + " " + snap.shortOf(sb), sb.id == sid, { ui.focusSid = sb.id; ui.focusTid = "" }, color = colorOf(sb.color))
                            }
                        }
                        val tops = snap.topicsOf(sid).filter { it.status != Status.DONE }.take(40)
                        if (tops.isNotEmpty()) {
                            Label("Topic (optional)")
                            ChipScroll {
                                Chip("Koi nahi", ui.focusTid.isEmpty(), { ui.focusTid = "" })
                                tops.forEach { tp -> Chip(tp.name, ui.focusTid == tp.id, { ui.focusTid = tp.id }) }
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Btn("Start", {
                        ui.strongHaptic(); ui.askNotif()
                        store.timerStart(sid, ui.focusTid, ui.focusFree)
                    }, Modifier.fillMaxWidth(), icon = Ic.Play, big = true)
                    Spacer(Modifier.height(8.dp))
                    Btn("Manual time add karo", { ui.open(Sheet.Manual) }, Modifier.fillMaxWidth(), kind = BtnKind.Ghost, icon = Ic.Plus)
                }
            }
        }

        // ------------------------------------------------------------ today
        val today = s.sessions.filter { it.date == snap.today }.sortedByDescending { it.ts }
        item {
            val total = today.sumOf { it.secs }
            SectionTitle("Aaj ke sessions · ${fmtDur(total)}" + if (s.cyc.date == snap.today && s.cyc.n > 0) " · 🍅 ${s.cyc.n}" else "")
        }
        if (today.isEmpty()) item { AppCard { Tx("Aaj abhi tak koi session nahi. Pehla 25 minute shuru karo!", size = 13.5.sp, color = c.sub) } }
        else item {
            AppCard {
                today.forEachIndexed { i, x ->
                    val sb = snap.sub(x.sid)
                    ItemRow(
                        fmtDur(x.secs) + if (x.manual) " · manual" else "",
                        sub = listOfNotNull(sb.name, snap.topic(x.tid)?.name, to12(nowHM(x.ts)).takeIf { !x.manual }).joinToString(" · "),
                        emoji = sb.emoji, color = colorOf(sb.color),
                        trailing = { IconBtn(Ic.Trash, { ui.confirm("Session delete?", fmtDur(x.secs) + " hata di jayegi.", "Delete") { store.commit { st -> st.deleteSession(x.id) } } }, tint = c.sub, size = 34.dp) }
                    )
                    if (i < today.size - 1) Divider()
                }
            }
        }
    }
}
