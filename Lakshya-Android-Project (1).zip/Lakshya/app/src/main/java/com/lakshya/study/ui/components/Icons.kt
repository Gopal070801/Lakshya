package com.lakshya.study.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/** Hand-drawn 24x24 line icons (no icon-font / extra dependency, crisp at any size). */
enum class Ic {
    Home, Plan, Focus, Syl, Test, Grid, Gear, Plus, Check, Trash, Edit, Close, Back, Next, Undo, Play, Pause, Stop,
    Star, Cards, Chart, Book, Clock, Target, Trophy, Palette, Down, Up, Search, Habit, Note, Table, Archive, Wand, Bell, Flame
}

private val ST = Stroke(width = 1.9f, cap = StrokeCap.Round, join = StrokeJoin.Round)

private fun DrawScope.ln(c: Color, x1: Float, y1: Float, x2: Float, y2: Float) =
    drawLine(c, Offset(x1, y1), Offset(x2, y2), 1.9f, StrokeCap.Round)

private fun DrawScope.circ(c: Color, cx: Float, cy: Float, r: Float, fill: Boolean = false) =
    drawCircle(c, r, Offset(cx, cy), style = if (fill) Fill else ST)

private fun DrawScope.rr(c: Color, x: Float, y: Float, w: Float, h: Float, r: Float, fill: Boolean = false) =
    drawRoundRect(c, Offset(x, y), Size(w, h), CornerRadius(r, r), style = if (fill) Fill else ST)

private fun DrawScope.pth(c: Color, fill: Boolean = false, b: Path.() -> Unit) =
    drawPath(Path().apply(b), c, style = if (fill) Fill else ST)

private fun Path.poly(vararg p: Float) {
    moveTo(p[0], p[1])
    var i = 2
    while (i + 1 < p.size) { lineTo(p[i], p[i + 1]); i += 2 }
}

private fun DrawScope.draw(ic: Ic, c: Color) {
    when (ic) {
        Ic.Home -> { pth(c) { poly(3f, 11f, 12f, 3f, 21f, 11f) }; pth(c) { poly(5f, 10f, 5f, 20f, 10f, 20f, 10f, 14f, 14f, 14f, 14f, 20f, 19f, 20f, 19f, 10f) } }
        Ic.Plan -> { rr(c, 3.5f, 5f, 17f, 15.5f, 3f); ln(c, 8f, 3f, 8f, 7f); ln(c, 16f, 3f, 16f, 7f); ln(c, 3.5f, 10f, 20.5f, 10f); pth(c) { poly(9f, 15f, 11f, 17f, 15f, 13f) } }
        Ic.Focus -> { circ(c, 12f, 13.5f, 7.5f); pth(c) { poly(12f, 9.5f, 12f, 13.5f, 14.5f, 15f) }; ln(c, 9.5f, 3f, 14.5f, 3f) }
        Ic.Syl -> { pth(c) { poly(12f, 3f, 3f, 8f, 12f, 13f, 21f, 8f, 12f, 3f) }; pth(c) { poly(3f, 12.5f, 12f, 17.5f, 21f, 12.5f) }; pth(c) { poly(3f, 17f, 12f, 22f, 21f, 17f) } }
        Ic.Test -> { rr(c, 5f, 4f, 14f, 17f, 3f); pth(c) { poly(9f, 3f, 15f, 3f, 15f, 6f, 9f, 6f, 9f, 3f) }; pth(c) { poly(9f, 13f, 11f, 15f, 15f, 11f) } }
        Ic.Grid -> { rr(c, 4f, 4f, 6.5f, 6.5f, 2f); rr(c, 13.5f, 4f, 6.5f, 6.5f, 2f); rr(c, 4f, 13.5f, 6.5f, 6.5f, 2f); rr(c, 13.5f, 13.5f, 6.5f, 6.5f, 2f) }
        Ic.Gear -> {
            circ(c, 12f, 12f, 3f)
            ln(c, 12f, 2.5f, 12f, 5.5f); ln(c, 12f, 18.5f, 12f, 21.5f); ln(c, 2.5f, 12f, 5.5f, 12f); ln(c, 18.5f, 12f, 21.5f, 12f)
            ln(c, 5.3f, 5.3f, 7.4f, 7.4f); ln(c, 16.6f, 16.6f, 18.7f, 18.7f); ln(c, 5.3f, 18.7f, 7.4f, 16.6f); ln(c, 16.6f, 7.4f, 18.7f, 5.3f)
        }
        Ic.Plus -> { ln(c, 12f, 5f, 12f, 19f); ln(c, 5f, 12f, 19f, 12f) }
        Ic.Check -> pth(c) { poly(5f, 13f, 9f, 17f, 19f, 7f) }
        Ic.Trash -> { ln(c, 4f, 7f, 20f, 7f); ln(c, 10f, 11f, 10f, 17f); ln(c, 14f, 11f, 14f, 17f); pth(c) { poly(6f, 7f, 7f, 20f, 17f, 20f, 18f, 7f) }; pth(c) { poly(9f, 7f, 9f, 4f, 15f, 4f, 15f, 7f) } }
        Ic.Edit -> pth(c) { poly(4f, 20f, 8f, 20f, 19f, 9f, 15f, 5f, 4f, 16f, 4f, 20f) }
        Ic.Close -> { ln(c, 6f, 6f, 18f, 18f); ln(c, 18f, 6f, 6f, 18f) }
        Ic.Back -> pth(c) { poly(15f, 5f, 8f, 12f, 15f, 19f) }
        Ic.Next -> pth(c) { poly(9f, 5f, 16f, 12f, 9f, 19f) }
        Ic.Undo -> { pth(c) { poly(9f, 14f, 4f, 9f, 9f, 4f) }; pth(c) { moveTo(4f, 9f); lineTo(14f, 9f); arcTo(Rect(8f, 9f, 20f, 21f), -90f, 180f, false); lineTo(11f, 21f) } }
        Ic.Play -> pth(c, true) { poly(7f, 4.5f, 7f, 19.5f, 19f, 12f); close() }
        Ic.Pause -> { rr(c, 6f, 4.5f, 4f, 15f, 1.2f, true); rr(c, 14f, 4.5f, 4f, 15f, 1.2f, true) }
        Ic.Stop -> rr(c, 6f, 6f, 12f, 12f, 2.5f, true)
        Ic.Star -> pth(c) {
            for (i in 0 until 10) {
                val r = if (i % 2 == 0) 9f else 3.9f
                val a = Math.toRadians((-90 + i * 36).toDouble())
                val x = 12f + r * cos(a).toFloat()
                val y = 12.6f + r * sin(a).toFloat()
                if (i == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }
        Ic.Cards -> { rr(c, 3.5f, 7f, 13f, 13f, 2.5f); pth(c) { poly(7.5f, 4f, 18.5f, 4f, 20.5f, 6f, 20.5f, 17f) } }
        Ic.Chart -> { ln(c, 4f, 20f, 4f, 10f); ln(c, 10f, 20f, 10f, 4f); ln(c, 16f, 20f, 16f, 13f); ln(c, 22f, 20f, 2f, 20f) }
        Ic.Book -> { rr(c, 5f, 3f, 14f, 18f, 2.5f); ln(c, 9f, 8f, 15f, 8f); ln(c, 9f, 12f, 13f, 12f) }
        Ic.Clock -> { circ(c, 12f, 12f, 8.5f); pth(c) { poly(12f, 7.5f, 12f, 12f, 15f, 14f) } }
        Ic.Target -> { circ(c, 12f, 12f, 8.5f); circ(c, 12f, 12f, 4.5f); circ(c, 12f, 12f, 1f, true) }
        Ic.Trophy -> {
            pth(c) { moveTo(7f, 4f); lineTo(17f, 4f); lineTo(17f, 9f); arcTo(Rect(7f, 4f, 17f, 14f), 0f, 180f, false); lineTo(7f, 4f) }
            ln(c, 12f, 14f, 12f, 18f); ln(c, 8f, 21f, 16f, 21f); ln(c, 9f, 18f, 15f, 18f)
            pth(c) { poly(7f, 6f, 4f, 6f, 4f, 8f); }; pth(c) { poly(17f, 6f, 20f, 6f, 20f, 8f) }
        }
        Ic.Palette -> { circ(c, 12f, 12f, 9f); circ(c, 7.5f, 11f, 1f, true); circ(c, 10f, 7f, 1f, true); circ(c, 15f, 7.5f, 1f, true) }
        Ic.Down -> { ln(c, 12f, 4f, 12f, 16f); pth(c) { poly(7f, 11f, 12f, 16f, 17f, 11f) }; ln(c, 5f, 20f, 19f, 20f) }
        Ic.Up -> { ln(c, 12f, 16f, 12f, 4f); pth(c) { poly(7f, 9f, 12f, 4f, 17f, 9f) }; ln(c, 5f, 20f, 19f, 20f) }
        Ic.Search -> { circ(c, 11f, 11f, 6.5f); ln(c, 16f, 16f, 20.5f, 20.5f) }
        Ic.Habit -> { drawArc(c, -60f, 270f, false, Offset(4f, 4f), Size(16f, 16f), style = ST); pth(c) { poly(20f, 4f, 20f, 9f, 15f, 9f) } }
        Ic.Note -> { rr(c, 4f, 3f, 16f, 18f, 3f); ln(c, 8f, 8f, 16f, 8f); ln(c, 8f, 12f, 16f, 12f); ln(c, 8f, 16f, 13f, 16f) }
        Ic.Table -> { rr(c, 3.5f, 4.5f, 17f, 15f, 3f); ln(c, 3.5f, 10f, 20.5f, 10f); ln(c, 9.5f, 10f, 9.5f, 19.5f) }
        Ic.Archive -> { rr(c, 3f, 4f, 18f, 4.5f, 1.5f); pth(c) { poly(5f, 8.5f, 5f, 19f, 6f, 20f, 18f, 20f, 19f, 19f, 19f, 8.5f) }; ln(c, 10f, 12.5f, 14f, 12.5f) }
        Ic.Wand -> { ln(c, 5f, 19f, 17f, 7f); pth(c) { poly(14f, 3.5f, 15f, 6f, 17.5f, 7f, 15f, 8f, 14f, 10.5f, 13f, 8f, 10.5f, 7f, 13f, 6f, 14f, 3.5f) } }
        Ic.Bell -> {
            pth(c) { moveTo(6f, 17f); lineTo(6f, 11f); arcTo(Rect(6f, 5f, 18f, 17f), 180f, 180f, false); lineTo(18f, 17f); lineTo(20f, 19f); lineTo(4f, 19f); lineTo(6f, 17f) }
            ln(c, 10f, 21.5f, 14f, 21.5f)
        }
        Ic.Flame -> pth(c) {
            moveTo(12f, 3f); cubicTo(13f, 6f, 17f, 8f, 17f, 13f); cubicTo(17f, 16f, 14.8f, 18f, 12f, 18f)
            cubicTo(9.2f, 18f, 7f, 16f, 7f, 13f); cubicTo(7f, 11f, 8f, 10f, 9f, 9f); cubicTo(9f, 11f, 10f, 12f, 11f, 12f); cubicTo(11f, 9f, 10f, 6f, 12f, 3f)
        }
    }
}

@Composable
fun Icon(ic: Ic, tint: Color, size: Dp = 22.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val u = this.size.width / 24f
        scale(u, Offset.Zero) { draw(ic, tint) }
    }
}
