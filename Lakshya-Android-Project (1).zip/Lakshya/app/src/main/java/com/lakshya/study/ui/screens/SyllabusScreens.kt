package com.lakshya.study.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.STAT
import com.lakshya.study.core.Status
import com.lakshya.study.core.cycleTopicStatus
import com.lakshya.study.core.fmtD
import com.lakshya.study.core.fmtHrs
import com.lakshya.study.core.loadPreset
import com.lakshya.study.core.pct
import com.lakshya.study.core.reviseTopic
import com.lakshya.study.ui.LocalSnap
import com.lakshya.study.ui.LocalStore
import com.lakshya.study.ui.LocalUi
import com.lakshya.study.ui.Dest
import com.lakshya.study.ui.Sheet
import com.lakshya.study.ui.components.AppCard
import com.lakshya.study.ui.components.Badge
import com.lakshya.study.ui.components.Btn
import com.lakshya.study.ui.components.BtnKind
import com.lakshya.study.ui.components.Chip
import com.lakshya.study.ui.components.ChipScroll
import com.lakshya.study.ui.components.Divider
import com.lakshya.study.ui.components.EmojiBubble
import com.lakshya.study.ui.components.EmptyCard
import com.lakshya.study.ui.components.Field
import com.lakshya.study.ui.components.Ic
import com.lakshya.study.ui.components.Icon
import com.lakshya.study.ui.components.IconBtn
import com.lakshya.study.ui.components.ProgressBar
import com.lakshya.study.ui.components.Ring
import com.lakshya.study.ui.components.Screen
import com.lakshya.study.ui.components.SectionTitle
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.components.colorOf
import com.lakshya.study.ui.components.pressable
import com.lakshya.study.ui.theme.Th

// ============================================================================ SYLLABUS
@Composable
fun SyllabusScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val c = Th.c
    val s = snap.s
    val active = snap.activeSubs
    val archived = s.subjects.filter { it.archived }
    val tops = s.topics.filter { !snap.sub(it.sid).archived }
    val done = tops.count { it.status == Status.DONE }
    val learning = tops.count { it.status == Status.LEARNING }

    Screen("Syllabus", subtitle = "${active.size} subjects · ${tops.size} topics") {
        if (s.subjects.isEmpty()) {
            item {
                EmptyCard("📚", "Syllabus khaali hai", "SSC MTS ka ready-made syllabus load karo ya apna subject banao.") {
                    Btn("SSC MTS syllabus load karo", { store.commit { it.loadPreset() } }, big = true)
                    Spacer(Modifier.height(8.dp))
                    Btn("Apna subject banao", { ui.open(Sheet.SubjectForm(null)) }, kind = BtnKind.Soft)
                }
            }
        } else {
            item {
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Ring(done.toFloat() / tops.size.coerceAtLeast(1), size = 84.dp, stroke = 9.dp) {
                            Tx("${pct(done, tops.size)}%", size = 17.sp, weight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Tx("$done / ${tops.size} complete", size = 16.sp, weight = FontWeight.Bold)
                            Tx("$learning padh rahe · ${snap.dueTopics.size} revision due", Modifier.padding(top = 2.dp), size = 12.5.sp, color = c.sub)
                            Tx(snap.syllabusForecast().text, Modifier.padding(top = 6.dp), size = 12.5.sp, color = if (snap.syllabusForecast().late) c.warn else c.sub, lineHeight = 17.sp)
                        }
                    }
                }
            }
            items(active, key = { it.id }) { sb -> SubjectCard(sb.id) }
            if (archived.isNotEmpty()) {
                item { SectionTitle("Archived") }
                items(archived, key = { it.id }) { sb -> SubjectCard(sb.id) }
            }
        }
    }
}

@Composable
private fun SubjectCard(sid: String) {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val c = Th.c
    val sb = snap.sub(sid)
    val p = snap.subProg(sid)
    val col = colorOf(sb.color)
    AppCard(onClick = { ui.go(Dest.Subject(sid)) }, container = if (sb.archived) c.surface.copy(alpha = 0.6f) else null) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            EmojiBubble(sb.emoji, col, 46.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tx(sb.name, Modifier.weight(1f, fill = false), size = 16.sp, weight = FontWeight.Bold, maxLines = 1)
                    if (sb.merit) { Spacer(Modifier.width(6.dp)); Badge("Merit", c.warn) }
                }
                Tx("${p.done}/${p.n} topics · ${p.learning} chal rahe", Modifier.padding(top = 2.dp), size = 12.5.sp, color = c.sub)
            }
            if (p.due > 0) Badge("🔁 ${p.due}", c.accText)
            Spacer(Modifier.width(8.dp))
            Tx("${p.pct}%", size = 15.sp, weight = FontWeight.Bold, color = col)
        }
        Spacer(Modifier.height(12.dp))
        ProgressBar(p.done.toFloat() / p.n.coerceAtLeast(1), col, frac2 = (p.done + p.learning).toFloat() / p.n.coerceAtLeast(1))
    }
}

// ============================================================================ SUBJECT
@Composable
fun StatusDot(status: String, color: Color, onClick: () -> Unit) {
    val c = Th.c
    Box(
        Modifier.size(30.dp).clip(CircleShape)
            .background(if (status == Status.DONE) c.ok else Color.Transparent)
            .border(2.dp, when (status) { Status.DONE -> c.ok; Status.LEARNING -> color; else -> c.sub.copy(alpha = 0.5f) }, CircleShape)
            .pressable(scaleTo = 0.85f, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        when (status) {
            Status.DONE -> Icon(Ic.Check, Color.White, 17.dp)
            Status.LEARNING -> Box(Modifier.size(12.dp).clip(CircleShape).background(color))
            else -> {}
        }
    }
}

@Composable
fun SubjectScreen(id: String) {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val c = Th.c
    val sb = snap.subOrNull(id)
    if (sb == null) {
        Screen("Subject", onBack = { ui.back() }) { item { EmptyCard("🤷", "Subject nahi mila", "Ye hata diya gaya hoga.") } }
        return
    }
    val col = colorOf(sb.color)
    var filter by remember { mutableStateOf("all") }
    var q by remember { mutableStateOf("") }
    val p = snap.subProg(id)
    val list = remember(snap.s.topics, filter, q, snap.today) {
        snap.topicsOf(id).filter { t ->
            (when (filter) { "due" -> snap.isDue(t); "all" -> true; else -> t.status == filter }) &&
                (q.isBlank() || t.name.contains(q.trim(), ignoreCase = true))
        }
    }
    val mb = snap.mistakesByTopic

    Screen(
        sb.name, onBack = { ui.back() }, subtitle = "${p.done}/${p.n} complete · ${fmtHrs(snap.secsBySub[id] ?: 0)} padha",
        actions = { IconBtn(Ic.Edit, { ui.open(Sheet.SubjectForm(id)) }, bg = c.surface) }
    ) {
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EmojiBubble(sb.emoji, col, 48.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Tx("${p.pct}% complete", size = 17.sp, weight = FontWeight.Bold)
                        Tx("${p.todo} baaki · ${p.learning} chal rahe · ${p.done} done", size = 12.5.sp, color = c.sub)
                    }
                    Btn("Focus", { ui.focusOn(id, "") }, kind = BtnKind.Soft)
                }
                Spacer(Modifier.height(12.dp))
                ProgressBar(p.done.toFloat() / p.n.coerceAtLeast(1), col, frac2 = (p.done + p.learning).toFloat() / p.n.coerceAtLeast(1))
            }
        }
        item {
            Column {
                ChipScroll {
                    Chip("Sab ${p.n}", filter == "all", { filter = "all" })
                    Chip("○ Baaki", filter == Status.TODO, { filter = Status.TODO })
                    Chip("◐ Chal rahe", filter == Status.LEARNING, { filter = Status.LEARNING })
                    Chip("● Done", filter == Status.DONE, { filter = Status.DONE })
                    if (p.due > 0) Chip("🔁 Due ${p.due}", filter == "due", { filter = "due" })
                }
                if (p.n > 8) { Spacer(Modifier.height(10.dp)); Field(q, { q = it }, hint = "Topic search…") }
            }
        }
        if (list.isEmpty()) item {
            EmptyCard("🗂", if (p.n == 0) "Koi topic nahi" else "Kuch nahi mila", if (p.n == 0) "+ dabake topics add karo (ek line = ek topic)." else "Filter badal ke dekho.")
        } else item {
            AppCard(padding = 8.dp) {
                list.forEachIndexed { i, t ->
                    val due = snap.isDue(t)
                    Row(
                        Modifier.fillMaxWidth().pressable(scaleTo = 0.985f) { ui.open(Sheet.TopicEdit(t.id)) }.padding(horizontal = 8.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusDot(t.status, col) { ui.tick(); store.commit { it.cycleTopicStatus(t.id, snap.today) } }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Tx(t.name, Modifier.weight(1f, fill = false), size = 15.sp, weight = FontWeight.SemiBold, maxLines = 2)
                                if (t.imp) { Spacer(Modifier.width(4.dp)); Tx("⭐", size = 12.sp) }
                            }
                            val bits = ArrayList<String>()
                            bits.add(STAT[t.status]?.label ?: "")
                            if (t.conf > 0) bits.add("${"★".repeat(t.conf)}")
                            if (t.status == Status.DONE && t.due.isNotEmpty()) bits.add("revise ${fmtD(t.due)}")
                            mb[t.id]?.let { if (it.n > 0) bits.add("❌ ${it.n}") }
                            Tx(bits.joinToString(" · "), Modifier.padding(top = 2.dp), size = 12.sp, color = if (due) c.warn else c.sub, maxLines = 1)
                        }
                        if (due) Btn("Revised", { ui.tick(); store.commit { it.reviseTopic(t.id, snap.today) }; ui.toast("Revision done ✅", "ok") }, kind = BtnKind.Soft)
                    }
                    if (i < list.size - 1) Divider(Modifier.padding(start = 50.dp))
                }
            }
        }
    }
}
