package com.lakshya.study.data

import android.app.Application
import com.lakshya.study.core.AppState
import com.lakshya.study.core.Codec
import com.lakshya.study.core.TimerOut
import com.lakshya.study.core.checkProgress
import com.lakshya.study.core.dateOf
import com.lakshya.study.core.timerFinish as coreFinish
import com.lakshya.study.core.timerStart as coreStart
import com.lakshya.study.core.timerTick
import com.lakshya.study.core.timerToggle as coreToggle
import com.lakshya.study.notify.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

sealed class UiEvent {
    class Toast(val msg: String, val type: String = "") : UiEvent()
    object Alert : UiEvent()
}

/**
 * Single source of truth. Lives in the Application, so it survives activity recreation and can be
 * driven by alarm receivers while the UI is closed. State is persisted as one JSON file
 * (same format as the old web app's backup, so it is also what Android Auto-Backup stores).
 */
class Store(private val app: Application) {

    private val file = File(app.filesDir, "lakshya.json")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Any()
    private val fileLock = Any()

    private val _state = MutableStateFlow(readFile())
    val state: StateFlow<AppState> = _state.asStateFlow()

    private val _now = MutableStateFlow(System.currentTimeMillis())
    /** Updated ~4×/s only while a timer exists. */
    val now: StateFlow<Long> = _now.asStateFlow()

    private val _today = MutableStateFlow(computeToday())
    val today: StateFlow<String> = _today.asStateFlow()

    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 16)
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    /** Launcher-shortcut / notification deep link, consumed by the UI. */
    val openRequest = MutableStateFlow<String?>(null)

    @Volatile private var ticker: Job? = null
    @Volatile private var saveJob: Job? = null

    init {
        scope.launch {
            while (isActive) { delay(20_000); refreshToday() }
        }
        ensureTicker()
    }

    // ------------------------------------------------------------------ file
    private fun readFile(): AppState {
        return try {
            if (!file.exists()) AppState() else {
                val txt = file.readText()
                val st = Codec.decodeOrDefault(txt)
                if (txt.isNotBlank() && st == AppState()) {
                    // unreadable file: keep a copy instead of silently overwriting it
                    runCatching { file.copyTo(File(file.parentFile, "lakshya.corrupt.json"), overwrite = true) }
                }
                st
            }
        } catch (e: Exception) {
            AppState()
        }
    }

    private fun writeNow() {
        val snapshot = _state.value
        synchronized(fileLock) {
            try {
                val tmp = File(file.parentFile, "lakshya.json.tmp")
                tmp.writeText(Codec.encode(snapshot))
                if (!tmp.renameTo(file)) { file.writeText(tmp.readText()); tmp.delete() }
            } catch (e: Exception) {
                // storage full etc. – next change retries
            }
        }
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = scope.launch { delay(250); writeNow() }
    }

    fun flushNow() {
        saveJob?.cancel()
        writeNow()
    }

    fun exportJson(): String = Codec.encode(_state.value)

    // ------------------------------------------------------------------ time
    private fun computeToday(): String =
        dateOf(System.currentTimeMillis(), _state.value.profile.dayStart)

    fun refreshToday() {
        val t = computeToday()
        if (t != _today.value) _today.value = t
    }

    fun onForeground() {
        refreshToday()
        _now.value = System.currentTimeMillis()
        tick()
        ensureTicker()
    }

    // ------------------------------------------------------------------ mutation core
    fun commit(f: (AppState) -> AppState) = mutate { TimerOut(f(it)) }

    private fun mutate(step: (AppState) -> TimerOut) {
        var prev: AppState? = null
        var out: TimerOut? = null
        var msgs: List<String> = emptyList()
        var cur: AppState? = null
        synchronized(lock) {
            val before = _state.value
            val o = step(before)
            if (o.state === before && o.message == null && !o.phaseEnded) return
            val today = dateOf(System.currentTimeMillis(), o.state.profile.dayStart)
            val pr = checkProgress(o.state, today)
            _state.value = pr.state
            prev = before; out = o; msgs = pr.messages; cur = pr.state
        }
        val p = prev ?: return
        val c = cur ?: return
        val o = out ?: return
        after(p, c, o, msgs)
    }

    private fun after(prev: AppState, cur: AppState, o: TimerOut, msgs: List<String>) {
        scheduleSave()
        val now = System.currentTimeMillis()
        refreshToday()
        if (prev.timer != cur.timer) Notifier.syncTimer(app, cur, now)
        if (prev.settings.remind != cur.settings.remind || prev.settings.remindTime != cur.settings.remindTime)
            Notifier.syncReminder(app, cur.settings)
        if (cur.timer != null) { _now.value = now; ensureTicker() }
        if (o.message != null) _events.tryEmit(UiEvent.Toast(o.message, "ok"))
        if (o.phaseEnded) {
            Notifier.phaseEnded(app, o.message ?: "Phase complete", cur.settings)
            _events.tryEmit(UiEvent.Alert)
        }
        msgs.forEach { _events.tryEmit(UiEvent.Toast(it, "ok")) }
    }

    fun toast(msg: String, type: String = "") { _events.tryEmit(UiEvent.Toast(msg, type)) }

    // ------------------------------------------------------------------ timer
    private fun ensureTicker() {
        if (_state.value.timer == null) return
        if (ticker?.isActive == true) return
        ticker = scope.launch {
            while (isActive) {
                delay(250)
                val t = _state.value.timer ?: break
                if (t.running) _now.value = System.currentTimeMillis()
                tick()
            }
        }
    }

    fun tick() = mutate { timerTick(it, System.currentTimeMillis()) }

    /** For alarm receivers: finish synchronously and make sure everything is on disk. */
    fun tickBlocking() {
        tick()
        flushNow()
    }

    fun timerStart(sid: String, tid: String, free: Boolean) {
        _now.value = System.currentTimeMillis()
        mutate { TimerOut(coreStart(it, sid, tid, free, System.currentTimeMillis())) }
    }

    fun timerToggle() = mutate { TimerOut(coreToggle(it, System.currentTimeMillis())) }
    fun timerFinish() = mutate { coreFinish(it, System.currentTimeMillis()) }
    fun timerDiscard() = mutate { TimerOut(it.copy(timer = null)) }
    fun timerDistraction() = mutate { s -> s.timer?.let { t -> TimerOut(s.copy(timer = t.copy(dist = t.dist + 1))) } ?: TimerOut(s) }
}
