package com.lakshya.study.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.ui.LocalBottomPad
import com.lakshya.study.ui.Tab
import com.lakshya.study.ui.theme.Motion
import com.lakshya.study.ui.theme.Th
import com.lakshya.study.ui.theme.tweenSpec
import kotlin.math.roundToInt

// ====================================================================== screen scaffold
private val TITLE_H = 88.dp
private val BAR_H = 56.dp

/** One UI style screen: large title that collapses into a small centred title while scrolling. */
@Composable
fun Screen(
    title: String,
    modifier: Modifier = Modifier,
    onBack: (() -> Unit)? = null,
    subtitle: String? = null,
    actions: @Composable RowScope.() -> Unit = {},
    content: LazyListScope.() -> Unit
) {
    val c = Th.c
    val d = Th.d
    val bottom = LocalBottomPad.current
    val state = rememberLazyListState()
    val density = LocalDensity.current
    val titlePx = with(density) { TITLE_H.toPx() }
    val collapse by remember {
        derivedStateOf {
            if (state.firstVisibleItemIndex > 0) 1f else (state.firstVisibleItemScrollOffset / titlePx).coerceIn(0f, 1f)
        }
    }
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    Box(modifier.fillMaxSize()) {
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = statusTop + BAR_H, bottom = bottom + 28.dp),
            verticalArrangement = Arrangement.spacedBy(d.gap)
        ) {
            item(key = "__title") {
                Column(Modifier.fillMaxWidth().height(TITLE_H).padding(start = 6.dp), verticalArrangement = Arrangement.Bottom) {
                    Tx(
                        title, Modifier.alpha(1f - collapse), size = 32.sp, weight = FontWeight.Bold, maxLines = 1
                    )
                    if (subtitle != null) Tx(subtitle, Modifier.alpha(1f - collapse).padding(top = 2.dp, bottom = 6.dp), size = 13.sp, color = c.sub, maxLines = 1)
                    else Box(Modifier.height(10.dp))
                }
            }
            content()
        }
        // top bar
        Box(
            Modifier.fillMaxWidth().background(c.bg.copy(alpha = collapse * 0.96f)).padding(top = statusTop).height(BAR_H)
        ) {
            Tx(
                title, Modifier.align(Alignment.Center).padding(horizontal = 96.dp).alpha(collapse), size = 17.sp,
                weight = FontWeight.SemiBold, maxLines = 1, align = TextAlign.Center
            )
            if (onBack != null) IconBtn(Ic.Back, onBack, Modifier.align(Alignment.CenterStart).padding(start = 6.dp), bg = c.surface)
            Row(Modifier.align(Alignment.CenterEnd).padding(end = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically, content = actions)
        }
    }
}

// ====================================================================== bottom sheet
@Composable
fun <T : Any> SheetHost(sheet: T?, onDismiss: () -> Unit, content: @Composable (T) -> Unit) {
    val holder = remember { arrayOfNulls<Any>(1) }
    if (sheet != null) holder[0] = sheet
    @Suppress("UNCHECKED_CAST")
    val shown: T? = sheet ?: (holder[0] as T?)
    val visible = sheet != null
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val maxH = maxHeight * 0.92f
        AnimatedVisibility(visible, enter = fadeIn(tweenSpec(220)), exit = fadeOut(tweenSpec(200))) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() }
            )
        }
        AnimatedVisibility(
            visible, modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(if (Th.motion == Motion.Off) 1 else 320, easing = com.lakshya.study.ui.theme.Emphasized)) { it } + fadeIn(tweenSpec(200)),
            exit = slideOutVertically(tween(if (Th.motion == Motion.Off) 1 else 240, easing = com.lakshya.study.ui.theme.Emphasized)) { it } + fadeOut(tweenSpec(200))
        ) {
            Box(Modifier.heightIn(max = maxH).widthIn(max = 640.dp)) {
                shown?.let { s -> key(s) { content(s) } }
            }
        }
    }
}

@Composable
fun SheetFrame(
    title: String,
    onClose: () -> Unit,
    footer: (@Composable RowScope.() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = Th.c
    var drag by remember { mutableFloatStateOf(0f) }
    Column(
        Modifier.fillMaxWidth()
            .offset { IntOffset(0, drag.roundToInt()) }
            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
            .background(c.surface)
            .navigationBarsPadding()
            .imePadding()
    ) {
        Column(
            Modifier.fillMaxWidth().draggable(
                orientation = Orientation.Vertical,
                state = rememberDraggableState { drag = (drag + it).coerceAtLeast(0f) },
                onDragStopped = { if (drag > 140f) onClose(); drag = 0f }
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.padding(top = 10.dp).width(40.dp).height(5.dp).clip(RoundedCornerShape(50)).background(c.sub.copy(alpha = 0.35f)))
            Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 10.dp, top = 6.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Tx(title, Modifier.weight(1f), size = 20.sp, weight = FontWeight.Bold, maxLines = 1)
                IconBtn(Ic.Close, onClose, bg = c.surface2, size = 38.dp)
            }
        }
        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 12.dp), content = content)
        if (footer != null) Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically, content = footer
        )
    }
}

// ====================================================================== confirm dialog
@Composable
fun ConfirmHost(req: com.lakshya.study.ui.ConfirmReq?, onDismiss: () -> Unit, onOk: () -> Unit) {
    val holder = remember { arrayOfNulls<com.lakshya.study.ui.ConfirmReq>(1) }
    if (req != null) holder[0] = req
    val shown = req ?: holder[0]
    val c = Th.c
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(req != null, enter = fadeIn(tweenSpec(180)), exit = fadeOut(tweenSpec(160))) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() }
            )
        }
        AnimatedVisibility(
            req != null, modifier = Modifier.align(Alignment.Center),
            enter = fadeIn(tweenSpec(200)) + scaleIn(tweenSpec(240), initialScale = 0.9f),
            exit = fadeOut(tweenSpec(140)) + scaleOut(tweenSpec(160), targetScale = 0.94f)
        ) {
            if (shown != null) Column(
                Modifier.padding(horizontal = 28.dp).widthIn(max = 420.dp).shadow(16.dp, RoundedCornerShape(28.dp))
                    .clip(RoundedCornerShape(28.dp)).background(c.surface).padding(22.dp)
            ) {
                Tx(shown.title, size = 18.sp, weight = FontWeight.Bold)
                Tx(shown.msg, Modifier.padding(top = 8.dp, bottom = 20.dp), size = 14.sp, color = c.sub)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Cancel", onDismiss, Modifier.weight(1f), BtnKind.Ghost)
                    Btn(shown.ok, onOk, Modifier.weight(1f), if (shown.danger) BtnKind.Danger else BtnKind.Primary)
                }
            }
        }
    }
}

// ====================================================================== toast
@Composable
fun ToastHost(msg: com.lakshya.study.ui.ToastMsg?, bottomPad: androidx.compose.ui.unit.Dp) {
    val c = Th.c
    val holder = remember { arrayOfNulls<com.lakshya.study.ui.ToastMsg>(1) }
    if (msg != null) holder[0] = msg
    val shown = msg ?: holder[0]
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
        AnimatedVisibility(
            msg != null, modifier = Modifier.padding(bottom = bottomPad + 8.dp, start = 24.dp, end = 24.dp),
            enter = fadeIn(tweenSpec(200)) + slideInVertically(tweenSpec(260)) { it / 2 },
            exit = fadeOut(tweenSpec(180)) + slideOutVertically(tweenSpec(200)) { it / 2 }
        ) {
            if (shown != null) {
                val tint = when (shown.type) { "ok" -> c.ok; "bad" -> c.bad; else -> Color.Transparent }
                Row(
                    Modifier.shadow(10.dp, RoundedCornerShape(50)).clip(RoundedCornerShape(50))
                        .background(if (c.light) Color(0xFF23262F) else Color(0xFF2C2F3A))
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (tint != Color.Transparent) { Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(tint)); Box(Modifier.width(10.dp)) }
                    Tx(shown.msg, size = 14.sp, color = Color.White, weight = FontWeight.Medium, maxLines = 3)
                }
            }
        }
    }
}

// ====================================================================== bottom navigation
val NAV_FLOAT_H = 72.dp
val NAV_BAR_H = 64.dp

@Composable
fun BottomNav(current: Tab, onSelect: (Tab) -> Unit, modifier: Modifier = Modifier) {
    val c = Th.c
    val d = Th.d
    val tabs = Tab.values()
    val container: Modifier = if (d.floatNav) {
        Modifier.padding(start = 14.dp, end = 14.dp, bottom = 10.dp).navigationBarsPadding()
            .shadow(14.dp, RoundedCornerShape(36.dp), ambientColor = Color(0x33000000), spotColor = Color(0x44000000))
            .clip(RoundedCornerShape(36.dp)).background(if (c.light) c.surface else c.surface2).height(NAV_FLOAT_H - 6.dp)
    } else {
        Modifier.background(if (c.light) c.surface else c.surface).navigationBarsPadding().height(NAV_BAR_H)
    }
    Box(modifier.then(if (d.floatNav) Modifier else Modifier.fillMaxWidth())) {
        Row(container.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            tabs.forEach { t ->
                val on = t == current
                Column(
                    Modifier.weight(1f).fillMaxSize().pressable(scaleTo = 0.9f) { onSelect(t) },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    val pillBg = androidx.compose.animation.animateColorAsState(if (on) c.accSoft else Color.Transparent, tweenSpec(220), label = "nav").value
                    val tint = androidx.compose.animation.animateColorAsState(if (on) c.accText else c.sub, tweenSpec(220), label = "navt").value
                    Box(Modifier.clip(RoundedCornerShape(50)).background(pillBg).padding(horizontal = 18.dp, vertical = 5.dp)) {
                        Icon(t.ic, tint, if (t == Tab.Focus) 26.dp else 23.dp)
                    }
                    Tx(t.label, Modifier.padding(top = 2.dp), size = 11.sp, weight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = tint, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun Fab(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = Th.c
    Box(
        modifier.size(58.dp).shadow(12.dp, RoundedCornerShape(if (Th.d.coloros) 20.dp else 29.dp), ambientColor = c.acc, spotColor = c.acc)
            .clip(RoundedCornerShape(if (Th.d.coloros) 20.dp else 29.dp)).background(c.grad).pressable(scaleTo = 0.9f, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(Ic.Plus, c.onAcc, 28.dp) }
}
