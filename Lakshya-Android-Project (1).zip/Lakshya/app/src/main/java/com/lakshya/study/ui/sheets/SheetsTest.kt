package com.lakshya.study.ui.sheets

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.Kind
import com.lakshya.study.core.REASONS
import com.lakshya.study.core.Section
import com.lakshya.study.core.TEST_TYPES
import com.lakshya.study.core.addMistakes
import com.lakshya.study.core.deleteMistake
import com.lakshya.study.core.ensureTopic
import com.lakshya.study.core.f2
import com.lakshya.study.core.reasonOf
import com.lakshya.study.core.saveTest
import com.lakshya.study.core.updateMistake
import com.lakshya.study.ui.Dest
import com.lakshya.study.ui.LocalSnap
import com.lakshya.study.ui.LocalStore
import com.lakshya.study.ui.LocalUi
import com.lakshya.study.ui.components.Btn
import com.lakshya.study.ui.components.BtnKind
import com.lakshya.study.ui.components.Chip
import com.lakshya.study.ui.components.ChipScroll
import com.lakshya.study.ui.components.DateField
import com.lakshya.study.ui.components.EmojiBubble
import com.lakshya.study.ui.components.Field
import com.lakshya.study.ui.components.Hint
import com.lakshya.study.ui.components.Label
import com.lakshya.study.ui.components.SettingRow
import com.lakshya.study.ui.components.SheetFrame
import com.lakshya.study.ui.components.Segmented
import com.lakshya.study.ui.components.Stepper
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.components.colorOf
import com.lakshya.study.ui.theme.Th

private val DEFAULT_TOTAL = mapOf("ga" to 25, "eng" to 25, "math" to 20, "reas" to 20)

// ============================================================================ TEST FORM
@Composable
fun TestSheet(id: String?) {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val c = Th.c
    val old = remember { snap.s.tests.firstOrNull { it.id == id } }
    var name by remember { mutableStateOf(old?.name ?: "Mock ${snap.s.tests.size + 1}") }
    var date by remember { mutableStateOf(old?.date ?: snap.today) }
    var type by remember { mutableStateOf(old?.type ?: TEST_TYPES[0]) }
    var mins by remember { mutableStateOf(old?.mins?.takeIf { it > 0 }?.toString() ?: "") }
    val subs = remember {
        snap.activeSubs + snap.s.subjects.filter { sb -> sb.archived && old?.sections?.containsKey(sb.id) == true }
    }
    val tot = remember { mutableStateMapOf<String, String>() }
    val cor = remember { mutableStateMapOf<String, String>() }
    val wr = remember { mutableStateMapOf<String, String>() }
    remember {
        subs.forEach { sb ->
            val sec = old?.sections?.get(sb.id)
            tot[sb.id] = sec?.total?.toString() ?: if (old == null) (DEFAULT_TOTAL[sb.id]?.toString() ?: "") else ""
            cor[sb.id] = sec?.correct?.toString() ?: ""
            wr[sb.id] = sec?.wrong?.toString() ?: ""
        }
        true
    }

    SheetFrame(
        if (old == null) "Naya mock test" else "Test edit", { ui.closeSheet() },
        footer = {
            Btn("Save", {
                if (name.isBlank()) { ui.toast("Test ka naam likho", "bad"); return@Btn }
                val secs = LinkedHashMap<String, Section>()
                for (sb in subs) {
                    val t = tot[sb.id]?.toIntOrNull() ?: 0
                    val co = cor[sb.id]?.toIntOrNull() ?: 0
                    val w = wr[sb.id]?.toIntOrNull() ?: 0
                    if (t <= 0 && co == 0 && w == 0) continue
                    if (co + w > t) { ui.toast("${sb.name}: sahi + galat total se zyada hai", "bad"); return@Btn }
                    secs[sb.id] = Section(t, co, w)
                }
                if (secs.isEmpty()) { ui.toast("Kam se kam ek section ke marks daalo", "bad"); return@Btn }
                val r = snap.s.saveTest(old?.id, name.trim(), date, mins.toIntOrNull() ?: 0, type, secs, System.currentTimeMillis())
                store.commit { r.first }
                ui.closeSheet()
                if (old == null) { ui.go(Dest.Test(r.second)); ui.toast("Test save hua. Ab galtiyan log karo 📓", "ok") }
            }, Modifier.weight(1f))
        }
    ) {
        Label("Naam", Modifier.padding(top = 4.dp)); Field(name, { name = it }, maxLen = 50)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1.4f)) { Label("Date"); DateField(date, { if (it.isNotEmpty()) date = it }, max = snap.today) }
            Column(Modifier.weight(1f)) { Label("Time (min)"); Field(mins, { mins = it.filter { ch -> ch.isDigit() } }, hint = "60", keyboard = KeyboardType.Number, maxLen = 3, center = true) }
        }
        Label("Type")
        ChipScroll { TEST_TYPES.forEach { ty -> Chip(ty, ty == type, { type = ty }) } }
        Label("Section-wise result")
        subs.forEach { sb ->
            val t = tot[sb.id]?.toIntOrNull() ?: 0
            val co = cor[sb.id]?.toIntOrNull() ?: 0
            val w = wr[sb.id]?.toIntOrNull() ?: 0
            Column(Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EmojiBubble(sb.emoji, colorOf(sb.color), 30.dp)
                    Spacer(Modifier.width(8.dp))
                    Tx(sb.name + if (sb.merit) " ⭐" else "", Modifier.weight(1f), size = 14.5.sp, weight = FontWeight.SemiBold, maxLines = 1)
                    if (t > 0) Tx("skip ${(t - co - w).coerceAtLeast(0)} · ${f2(co * snap.mc - w * snap.ng)}", size = 12.sp, color = c.sub)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumBox("Total", tot[sb.id] ?: "", Modifier.weight(1f)) { tot[sb.id] = it }
                    NumBox("Sahi ✅", cor[sb.id] ?: "", Modifier.weight(1f)) { cor[sb.id] = it }
                    NumBox("Galat ❌", wr[sb.id] ?: "", Modifier.weight(1f)) { wr[sb.id] = it }
                }
            }
        }
        Hint("Marking: +${f2(snap.mc)} sahi, −${f2(snap.ng)} galat. Settings me badal sakte ho.")
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun NumBox(label: String, v: String, modifier: Modifier, onChange: (String) -> Unit) {
    Column(modifier) {
        Tx(label, Modifier.padding(start = 4.dp, bottom = 4.dp), size = 11.5.sp, color = Th.c.sub, maxLines = 1)
        Field(v, { onChange(it.filter { ch -> ch.isDigit() }) }, hint = "0", keyboard = KeyboardType.Number, maxLen = 3, center = true)
    }
}

// ============================================================================ MISTAKE FORM
@Composable
fun MistakeSheet(id: String?, testId: String?) {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val old = remember { snap.s.mistakes.firstOrNull { it.id == id } }
    val tid0 = old?.testId ?: testId ?: ""
    val test = remember { snap.s.tests.firstOrNull { it.id == tid0 } }
    val pend = remember { if (old == null && test != null) snap.pendingCombo(test, test.sections.keys) else null }

    var sid by remember { mutableStateOf(old?.sid ?: pend?.sid ?: test?.sections?.keys?.firstOrNull() ?: snap.activeSubs.firstOrNull()?.id ?: "") }
    var kind by remember { mutableStateOf(old?.kind ?: pend?.kind ?: if (test != null) Kind.WRONG else Kind.NOTE) }
    var tid by remember { mutableStateOf(old?.tid ?: "") }
    var newTopic by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf(old?.reason ?: "silly") }
    var q by remember { mutableStateOf(old?.q ?: "") }
    var ans by remember { mutableStateOf(old?.ans ?: "") }
    var qty by remember { mutableIntStateOf(1) }
    var formKey by remember { mutableIntStateOf(0) }

    fun save(close: Boolean) {
        if (sid.isEmpty()) { ui.toast("Subject chuno", "bad"); return }
        if (kind == Kind.NOTE && q.isBlank() && ans.isBlank() && tid.isEmpty() && newTopic.isBlank()) { ui.toast("Kuch likho ya topic chuno", "bad"); return }
        val nt = newTopic.trim()
        val now = System.currentTimeMillis()
        if (old != null) {
            store.commit { st ->
                val (a, tp) = if (nt.isNotEmpty()) st.ensureTopic(sid, nt) else st to null
                a.updateMistake(old.id, sid, kind, tp?.id ?: tid, reason, q.trim(), ans.trim())
            }
        } else {
            store.commit { st ->
                val (a, tp) = if (nt.isNotEmpty()) st.ensureTopic(sid, nt) else st to null
                a.addMistakes(tid0, sid, tp?.id ?: tid, kind, reason, q.trim(), ans.trim(), if (test != null) qty else 1, now, snap.today)
            }
        }
        ui.toast("Notebook me save ✅", "ok")
        if (close || old != null) ui.closeSheet()
        else { q = ""; ans = ""; qty = 1; formKey++ }
    }

    SheetFrame(
        when { old != null -> "Card edit"; test != null -> "Galti log karo"; else -> "Naya note" }, { ui.closeSheet() },
        footer = {
            if (old != null) Btn("Delete", { store.commit { it.deleteMistake(old.id) }; ui.closeSheet() }, kind = BtnKind.Danger)
            if (old == null && test != null) Btn("Save + agla", { save(false) }, kind = BtnKind.Soft)
            Btn("Save", { save(true) }, Modifier.weight(1f))
        }
    ) {
        if (test != null) {
            val (need, got) = snap.logProgress(test)
            Tx(test.name + " · $got/$need log hui", Modifier.padding(top = 2.dp), size = 12.5.sp, color = Th.c.sub)
        }
        Label("Subject", Modifier.padding(top = if (test != null) 8.dp else 4.dp))
        SubChips(sid, { sid = it; tid = "" }, only = test?.sections?.keys)
        Label("Type")
        Segmented(
            if (test != null) listOf(Kind.WRONG to "❌ Galat", Kind.SKIP to "⏭ Skip") else listOf(Kind.WRONG to "❌ Galat", Kind.SKIP to "⏭ Skip", Kind.NOTE to "📝 Note"),
            kind, { kind = it }
        )
        if (sid.isNotEmpty()) { Label("Topic"); TopicChips(sid, tid) { tid = it; if (it.isNotEmpty()) newTopic = "" } }
        Spacer(Modifier.height(8.dp))
        Field(newTopic, { newTopic = it; if (it.isNotBlank()) tid = "" }, hint = "Ya naya topic likho…", maxLen = 60)
        Label("Galti kyun hui?")
        ChipScroll { REASONS.forEach { r -> Chip(r.ico + " " + r.short, reason == r.key, { reason = r.key }, color = colorOf(r.color)) } }
        Spacer(Modifier.height(8.dp))
        Hint(reasonOf(reason).label + ": " + reasonOf(reason).fix)
        androidx.compose.runtime.key(formKey) {
            Label("Question / concept (optional)")
            Field(q, { q = it }, hint = "Question ya point jo yaad rakhna hai", singleLine = false, minLines = 2, maxLen = 600)
            Label("Sahi jawab (optional)")
            Field(ans, { ans = it }, hint = "Correct answer / explanation", singleLine = false, minLines = 2, maxLen = 600)
        }
        if (old == null && test != null) {
            SettingRow("Itne questions ka same reason", "$qty question" + if (qty > 1) "s" else "") {
                Stepper({ qty = (qty - 1).coerceAtLeast(1) }, { qty = (qty + 1).coerceAtMost(30) })
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
