package com.lakshya.study.notify

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.lakshya.study.MainActivity
import com.lakshya.study.R
import com.lakshya.study.core.AppState
import com.lakshya.study.core.Settings
import com.lakshya.study.core.Snap
import com.lakshya.study.core.TimerState
import com.lakshya.study.core.dateOf
import com.lakshya.study.core.fmtDur
import com.lakshya.study.core.tElapsed
import com.lakshya.study.core.timerEndAt
import java.util.Calendar

object Notifier {
    const val CH_TIMER = "timer"
    const val CH_REMIND = "remind"
    const val ACTION_TIMER = "com.lakshya.study.action.TIMER_END"
    const val ACTION_REMIND = "com.lakshya.study.action.REMIND"
    private const val ID_TIMER = 11
    private const val ID_ALERT = 12
    private const val ID_REMIND = 13
    private const val RC_TIMER = 21
    private const val RC_REMIND = 22
    private const val RC_OPEN = 23

    fun alertChannel(sound: Boolean, vibrate: Boolean) = "alert_" + (if (sound) "s" else "") + (if (vibrate) "v" else "")

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val timer = NotificationChannel(CH_TIMER, "Focus timer", NotificationManager.IMPORTANCE_LOW)
        timer.description = "Chalte hue focus timer ka status"
        timer.setShowBadge(false)
        nm.createNotificationChannel(timer)

        val rem = NotificationChannel(CH_REMIND, "Daily reminder", NotificationManager.IMPORTANCE_DEFAULT)
        rem.description = "Roz padhai ka yaad dilana"
        nm.createNotificationChannel(rem)

        for (sound in listOf(true, false)) for (vib in listOf(true, false)) {
            val ch = NotificationChannel(alertChannel(sound, vib), "Timer alerts" + (if (sound) "" else " (silent)") + (if (vib) "" else " (no vibration)"), NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Focus / break khatam hone par alert"
            if (!sound) ch.setSound(null, null)
            ch.enableVibration(vib)
            if (vib) ch.vibrationPattern = longArrayOf(0, 220, 90, 220, 90, 320)
            nm.createNotificationChannel(ch)
        }
    }

    fun canNotify(ctx: Context): Boolean = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    private fun openIntent(ctx: Context, action: String? = null): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (action != null) i.action = action
        return PendingIntent.getActivity(ctx, RC_OPEN, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    // ------------------------------------------------------------------ timer notification + alarm
    @SuppressLint("MissingPermission")
    fun syncTimer(ctx: Context, s: AppState, nowMs: Long) {
        val nm = NotificationManagerCompat.from(ctx)
        val t = s.timer
        val end = timerEndAt(t)
        if (end != null) scheduleAlarm(ctx, RC_TIMER, ACTION_TIMER, end) else cancelAlarm(ctx, RC_TIMER, ACTION_TIMER)
        if (t == null) { nm.cancel(ID_TIMER); return }
        if (!canNotify(ctx)) return
        nm.notify(ID_TIMER, timerNotification(ctx, s, t, nowMs))
    }

    private fun timerNotification(ctx: Context, s: AppState, t: TimerState, nowMs: Long): android.app.Notification {
        val subj = s.subjects.firstOrNull { it.id == t.sid }
        val where = subj?.let { it.emoji + " " + it.name } ?: "Padhai"
        val title = when {
            t.phase != "focus" -> "☕ Break chal raha hai"
            t.running -> "🎯 Focus chal raha hai"
            else -> "⏸ Focus paused"
        }
        val b = NotificationCompat.Builder(ctx, CH_TIMER)
            .setSmallIcon(R.drawable.ic_stat_target)
            .setContentTitle(title)
            .setContentText(where)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setContentIntent(openIntent(ctx, "com.lakshya.study.action.FOCUS"))
        if (t.running) {
            b.setShowWhen(true)
            b.setUsesChronometer(true)
            val end = timerEndAt(t)
            if (end != null) { b.setWhen(end); b.setChronometerCountDown(true) }
            else b.setWhen(nowMs - (tElapsed(t, nowMs) * 1000).toLong())
        } else {
            b.setShowWhen(false)
            b.setSubText("Paused · " + fmtDur(tElapsed(t, nowMs)))
        }
        return b.build()
    }

    @SuppressLint("MissingPermission")
    fun phaseEnded(ctx: Context, msg: String, st: Settings) {
        if (!canNotify(ctx)) return
        val n = NotificationCompat.Builder(ctx, alertChannel(st.sound, st.haptics))
            .setSmallIcon(R.drawable.ic_stat_target)
            .setContentTitle(msg)
            .setContentText("Tap karke wapas aao")
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openIntent(ctx, "com.lakshya.study.action.FOCUS"))
            .build()
        NotificationManagerCompat.from(ctx).notify(ID_ALERT, n)
    }

    // ------------------------------------------------------------------ alarms
    private fun pending(ctx: Context, rc: Int, action: String): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(ctx, rc, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun scheduleAlarm(ctx: Context, rc: Int, action: String, at: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, rc, action)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun cancelAlarm(ctx: Context, rc: Int, action: String) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, rc, action))
    }

    // ------------------------------------------------------------------ daily reminder
    fun nextReminderAt(time: String, nowMs: Long): Long {
        val p = time.split(":")
        val c = Calendar.getInstance()
        c.timeInMillis = nowMs
        c.set(Calendar.HOUR_OF_DAY, p.getOrNull(0)?.toIntOrNull() ?: 20)
        c.set(Calendar.MINUTE, p.getOrNull(1)?.toIntOrNull() ?: 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= nowMs + 1000) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    fun syncReminder(ctx: Context, st: Settings) {
        if (st.remind) scheduleAlarm(ctx, RC_REMIND, ACTION_REMIND, nextReminderAt(st.remindTime, System.currentTimeMillis()))
        else cancelAlarm(ctx, RC_REMIND, ACTION_REMIND)
    }

    @SuppressLint("MissingPermission")
    fun showReminder(ctx: Context, s: AppState) {
        if (!canNotify(ctx)) return
        val today = dateOf(System.currentTimeMillis(), s.profile.dayStart)
        val snap = Snap(s, today)
        val studied = (snap.dayMap[today] ?: 0)
        val goal = s.profile.dailyGoal * 60
        val parts = ArrayList<String>()
        if (snap.dueTopics.isNotEmpty()) parts.add("${snap.dueTopics.size} topics revise karne hain")
        if (snap.dueCards.isNotEmpty()) parts.add("${snap.dueCards.size} mistake cards due")
        val text = (if (studied < goal) "Aaj ${fmtDur(studied)} / ${fmtDur(goal)} ho chuka. " else "Goal complete! 🎉 ") +
            (if (parts.isEmpty()) "Ek focus session shuru karo." else parts.joinToString(" · "))
        val n = NotificationCompat.Builder(ctx, CH_REMIND)
            .setSmallIcon(R.drawable.ic_stat_target)
            .setContentTitle("🎯 Padhai ka time!" + if (snap.streak.cur > 0) "  🔥 ${snap.streak.cur} din" else "")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openIntent(ctx))
            .build()
        NotificationManagerCompat.from(ctx).notify(ID_REMIND, n)
    }
}
